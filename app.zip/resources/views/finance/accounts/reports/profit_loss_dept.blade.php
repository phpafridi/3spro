<!DOCTYPE html>
<html>
<head>
<title>P&L Department</title>
<link href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" rel="stylesheet">
<style>
body{font-family:Arial,sans-serif;padding:20px;}
th{background:#555;color:#fff;padding:8px;}
td{padding:6px 10px;border-bottom:1px solid #eee;font-size:13px;}
h3,p{text-align:center;}
.pos{color:green;font-weight:bold;}
.neg{color:red;font-weight:bold;}
</style>
</head>
<body>
<div id="company-header" style="text-align:center;margin-bottom:12px;font-family:Arial,sans-serif;border-bottom:2px solid #555;padding-bottom:8px;">
    @php $logoPath = public_path(config('company.logo_path')); @endphp
    @if(file_exists($logoPath))
        <img src="{{ asset(config('company.logo_path')) }}" alt="{{ config('company.name') }}" style="height:52px;display:block;margin:0 auto 4px;" onerror="this.style.display='none'">
    @endif
    <div style="font-size:18px;font-weight:bold;letter-spacing:2px;text-transform:uppercase;">{{ config('company.name') }}</div>
    <div style="font-size:10px;color:#444;margin-top:2px;">{{ config('company.location') }} &nbsp;|&nbsp; {{ config('company.phone') }}</div>
</div>

<h3>{{ $deptName }} — Profit/Loss Report</h3>
<p>{{ $from }} to {{ $to }}</p>
<table>
  <tr><td>Total Income</td><td class="pos">{{ number_format($totalIncome,2) }}</td></tr>
  <tr><td>Total Expense</td><td class="neg">{{ number_format($totalExpense,2) }}</td></tr>
  <tr style="background:#222;color:#fff;"><td><strong>Net P/L</strong></td>
    <td class="{{ $net >= 0 ? 'pos' : 'neg' }}"><strong>{{ number_format($net,2) }}</strong></td></tr>
</table>
</body></html>
