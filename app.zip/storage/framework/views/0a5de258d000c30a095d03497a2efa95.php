<?php $__env->startSection('title', 'Workshop Return - Parts'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h2 class="text-2xl font-bold text-gray-800">Workshop Parts Return</h2>
</div>
<?php if(session('success')): ?><div class="mb-4 p-4 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-700 rounded-r-xl"><?php echo e(session('success')); ?></div><?php endif; ?>
<div class="mb-6">
<h3 class="font-semibold text-gray-700 mb-3">Parts Returns Pending</h3>
<div class="bg-white rounded shadow-sm border border-gray-200 overflow-hidden">
<table class="w-full text-sm">
    <thead class="bg-red-50"><tr>
        <th class="px-4 py-3 text-left text-xs text-gray-600">Part #</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600">RO No</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600">Description</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600">Location</th>
        <th class="px-4 py-3 text-center text-xs text-gray-600">Action</th>
    </tr></thead>
    <tbody class="divide-y divide-gray-100">
    <?php $__empty_1 = true; $__currentLoopData = $returnParts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="hover:bg-red-50/30">
        <td class="px-4 py-3 font-medium"><?php echo e($p->part_number); ?></td>
        <td class="px-4 py-3"><?php echo e($p->RO_no); ?></td>
        <td class="px-4 py-3"><?php echo e($p->Description); ?></td>
        <td class="px-4 py-3 text-gray-500 text-xs"><?php echo e($p->Location); ?></td>
        <td class="px-4 py-3 text-center">
            <form action="<?php echo e(route('parts.workshop-return.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="not_available_id" value="<?php echo e($p->parts_sale_id); ?>">
                <button type="submit" class="px-3 py-1 bg-red-500 text-white text-xs rounded hover:bg-red-600">Mark N/A</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="5" class="px-4 py-8 text-center text-gray-400">No parts returns pending</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
</div>
<div>
<h3 class="font-semibold text-gray-700 mb-3">Consumable Returns Pending</h3>
<div class="bg-white rounded shadow-sm border border-gray-200 overflow-hidden">
<table class="w-full text-sm">
    <thead class="bg-red-50"><tr>
        <th class="px-4 py-3 text-left text-xs text-gray-600">ID</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600">RO No</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600">Customer</th>
        <th class="px-4 py-3 text-center text-xs text-gray-600">Action</th>
    </tr></thead>
    <tbody class="divide-y divide-gray-100">
    <?php $__empty_1 = true; $__currentLoopData = $returnConsumbles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="hover:bg-red-50">
        <td class="px-4 py-3 font-medium"><?php echo e($c->cons_sale_id); ?></td>
        <td class="px-4 py-3"><?php echo e($c->RO_no); ?></td>
        <td class="px-4 py-3"><?php echo e($c->customer_name); ?></td>
        <td class="px-4 py-3 text-center">
            <form action="<?php echo e(route('parts.workshop-return.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="not_available_cons" value="<?php echo e($c->cons_sale_id); ?>">
                <button type="submit" class="px-3 py-1 bg-red-500 text-white text-xs rounded hover:bg-red-600">Mark N/A</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="4" class="px-4 py-8 text-center text-gray-400">No consumable returns pending</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\3spro\resources\views/parts/entry/wp_return.blade.php ENDPATH**/ ?>