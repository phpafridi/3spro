<?php $__env->startSection('title', 'Sales - Parts Status'); ?>
<?php $__env->startSection('sidebar-menu'); ?> <?php echo $__env->make('sales.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-4">
    <h2 class="text-xl font-semibold text-gray-800">Parts Status — In Workshop</h2>
    <a href="<?php echo e(route('sales.index')); ?>" class="px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white text-sm rounded transition-colors"><i class="fa fa-home mr-1"></i>Dashboard</a>
</div>
<?php if($jobcards->isEmpty()): ?>
    <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded"><i class="fa fa-check-circle mr-2"></i>No jobcards in workshop.</div>
<?php else: ?>
    <?php $__currentLoopData = $jobcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(isset($partsData[$jc->Jobc_id]) && count($partsData[$jc->Jobc_id])): ?>
    <div class="bg-white rounded shadow-sm p-5 mb-4">
        <div class="flex items-center gap-4 mb-3 pb-3 border-b border-gray-100">
            <span class="font-bold text-gray-900">RO# <?php echo e($jc->Jobc_id); ?></span>
            <span class="text-gray-500 text-sm">SA: <?php echo e($jc->SA); ?></span>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50"><tr>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Part</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Entry</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Issue Time</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                </tr></thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $partsData[$jc->Jobc_id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-2 text-sm font-medium text-gray-800"><?php echo e($p->part_description); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-400"><?php echo e($p->entry_datetime); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-400"><?php echo e($p->issue_time ?? '—'); ?></td>
                        <td class="px-4 py-2 text-sm">
                            <?php if($p->status=='0'): ?><span class="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs rounded-full">Pending</span>
                            <?php else: ?><span class="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full">Issued</span><?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\3spro\resources\views/sales/status-parts.blade.php ENDPATH**/ ?>