<?php $__env->startSection('title', 'Invoice View - Parts'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6 flex items-center justify-between">
    <div>
        <h2 class="text-2xl font-bold text-gray-800">Invoice #<?php echo e($invoice->Invoice_no); ?></h2>
        <p class="text-sm text-gray-500">
            Jobber: <strong><?php echo e($invoice->jobber); ?></strong> &bull;
            Bill#: <?php echo e($invoice->Invoice_number); ?> &bull;
            Date: <?php echo e($invoice->mdate ? \Carbon\Carbon::parse($invoice->mdate)->format('d M Y') : '-'); ?>

        </p>
    </div>
    <div class="flex gap-2">
        <a href="<?php echo e(route('parts.purchase.detail', $invoice->Invoice_no)); ?>"
           class="px-4 py-2 bg-red-100 text-red-700 rounded text-sm hover:bg-red-100 transition-colors">
            + Add Parts
        </a>
        <a href="<?php echo e(route('parts.print.purchase', $invoice->Invoice_no)); ?>" target="_blank"
           class="px-4 py-2 bg-red-600 text-white rounded text-sm hover:bg-red-700 transition-colors">
            Print Invoice
        </a>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
    <div class="bg-white rounded border border-gray-200 p-4">
        <p class="text-xs text-gray-500">Payment Method</p>
        <p class="font-semibold text-gray-800"><?php echo e($invoice->payment_method); ?></p>
    </div>
    <div class="bg-white rounded border border-gray-200 p-4">
        <p class="text-xs text-gray-500">Purchase Requisition</p>
        <p class="font-semibold text-gray-800"><?php echo e($invoice->Purchase_Requis); ?></p>
    </div>
    <div class="bg-white rounded border border-gray-200 p-4">
        <p class="text-xs text-gray-500">Total Amount</p>
        <p class="font-semibold text-gray-800 text-xl"><?php echo e(number_format($invoice->Total_amount ?? 0, 2)); ?></p>
    </div>
</div>

<div class="bg-white rounded shadow-sm border border-gray-200 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gradient-to-r from-red-50 to-red-50">
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">#</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Part No</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Description</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Category</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Unit</th>
                    <th class="px-4 py-3 text-right text-xs font-semibold text-gray-600 uppercase">Qty</th>
                    <th class="px-4 py-3 text-right text-xs font-semibold text-gray-600 uppercase">Remain</th>
                    <th class="px-4 py-3 text-right text-xs font-semibold text-gray-600 uppercase">Price</th>
                    <th class="px-4 py-3 text-right text-xs font-semibold text-gray-600 uppercase">Net Amt</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__currentLoopData = $invoice->stockItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-red-50/30">
                    <td class="px-4 py-3 text-gray-500"><?php echo e($i+1); ?></td>
                    <td class="px-4 py-3 font-medium text-gray-800"><?php echo e($item->part_no); ?></td>
                    <td class="px-4 py-3 text-gray-700"><?php echo e($item->Description); ?></td>
                    <td class="px-4 py-3 text-gray-500 text-xs"><?php echo e($item->cate_type); ?></td>
                    <td class="px-4 py-3 text-gray-500 text-xs"><?php echo e($item->unit); ?></td>
                    <td class="px-4 py-3 text-right"><?php echo e($item->quantity); ?></td>
                    <td class="px-4 py-3 text-right <?php echo e($item->remain_qty <= 0 ? 'text-red-600' : 'text-green-700'); ?>"><?php echo e($item->remain_qty); ?></td>
                    <td class="px-4 py-3 text-right"><?php echo e(number_format($item->Price, 2)); ?></td>
                    <td class="px-4 py-3 text-right font-semibold"><?php echo e(number_format($item->Netamount, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot class="bg-gray-50">
                <tr>
                    <td colspan="8" class="px-4 py-3 text-right font-bold text-gray-700">Total:</td>
                    <td class="px-4 py-3 text-right font-bold text-gray-900 text-base"><?php echo e(number_format($invoice->Total_amount ?? 0, 2)); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/parts/entry/pur_det2.blade.php ENDPATH**/ ?>