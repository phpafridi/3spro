<?php $__env->startSection('title', 'Add Part - RO# ' . $jobId); ?>
<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('service.partials.jobcard-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?><div class="mb-4 p-3 bg-green-100 text-green-800 rounded-md"><?php echo e(session('success')); ?></div><?php endif; ?>

<?php
    $storeRoute = ($jobcard->status >= 1)
        ? route('jobcard.additional.part.post-store')
        : route('jobcard.additional.part.store');
    $grandTotal = $parts->sum('total');
?>

<div class="grid grid-cols-1 md:grid-cols-5 gap-6">
    
    <div class="md:col-span-2 bg-white rounded shadow-sm p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-lg font-semibold text-gray-800">Add Part — RO# <?php echo e($jobId); ?></h2>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('jobcard.additional', $jobId)); ?>" class="px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-medium rounded transition-colors">
                    <i class="fa fa-eye mr-1"></i> View RO
                </a>
                <a href="<?php echo e(route('jobcard.additional-list')); ?>" class="text-sm text-gray-500 hover:text-gray-700"><i class="fa fa-arrow-left mr-1"></i>Back</a>
            </div>
        </div>
        <form method="POST" action="<?php echo e($storeRoute); ?>" class="space-y-3">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="job_id" value="<?php echo e($jobId); ?>">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Part Description <span class="text-red-500">*</span></label>
                <div class="relative">
                    <input type="text" name="part_description" id="part_input" required autocomplete="off"
                           placeholder="Type to search part..."
                           class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <div id="parts_dropdown"
                         class="absolute z-50 w-full bg-white border border-gray-200 rounded-md shadow-lg mt-1 max-h-48 overflow-y-auto hidden">
                    </div>
                </div>
                <p class="text-xs text-gray-400 mt-0.5">Select from list or type a custom description</p>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Qty <span class="text-red-500">*</span></label>
                    <input type="number" name="qty" id="qty_input" min="1" step="1" value="1" required onchange="calcTotal()"
                           class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Unit Price <span class="text-red-500">*</span></label>
                    <input type="number" name="unitprice" id="unitprice_input" step="0.01" min="0.01" required onchange="calcTotal()"
                           class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Total</label>
                <input type="number" name="totalprice" id="total_input" step="0.01" readonly
                       class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm bg-gray-50">
            </div>
            <button type="submit" class="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md transition-colors">
                <i class="fa fa-plus mr-2"></i> Add Part
            </button>
        </form>
    </div>

    
    <div class="md:col-span-3 bg-white rounded shadow-sm p-6">
        <div class="flex items-center justify-between mb-3">
            <h3 class="font-semibold text-gray-700">Current Parts
                <span class="ml-2 px-2 py-0.5 bg-gray-100 text-gray-600 text-sm rounded-full"><?php echo e($parts->count()); ?></span>
            </h3>
            <?php if($grandTotal > 0): ?>
            <div class="text-right">
                <span class="text-xs text-gray-500 block">Parts Total</span>
                <span class="text-lg font-bold text-green-700"><?php echo e(number_format($grandTotal, 2)); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50"><tr>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Qty</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Unit</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Del</th>
            </tr></thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($p->part_description); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($p->qty); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e(number_format($p->unitprice,2)); ?></td>
                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e(number_format($p->total,2)); ?></td>
                    <td class="px-4 py-2 text-sm">
                        <?php if($p->Additional == 1 && $p->status == 0): ?>
                            <span class="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full">Additional</span>
                        <?php elseif($p->status >= 1): ?>
                            <span class="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full">Issued</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs rounded-full">Pending</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-2">
                        <?php if($p->status == 0 && $p->issued_qty == 0): ?>
                        <button class="delete-item-btn px-2 py-1 bg-red-500 hover:bg-red-600 text-white text-xs rounded"
                                data-id="<?php echo e($p->parts_sale_id); ?>" data-type="part">
                            <i class="fa fa-trash"></i>
                        </button>
                        <?php else: ?>
                        <span class="text-gray-300 text-xs">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="px-4 py-4 text-center text-gray-400 text-sm italic">No parts added yet.</td></tr>
                <?php endif; ?>
            </tbody>
            <?php if($grandTotal > 0): ?>
            <tfoot>
                <tr class="bg-green-50 border-t-2 border-green-200">
                    <td colspan="3" class="px-4 py-2 text-sm font-semibold text-gray-700 text-right">Grand Total:</td>
                    <td class="px-4 py-2 text-sm font-bold text-green-700"><?php echo e(number_format($grandTotal, 2)); ?></td>
                    <td colspan="2"></td>
                </tr>
            </tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>

<?php echo $__env->make('service.jobcard.partials.ro-overview-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const partsList = <?php echo json_encode($partsList ?? [], 15, 512) ?>;

function calcTotal() {
    var qty = parseFloat(document.getElementById('qty_input').value) || 0;
    var up  = parseFloat(document.getElementById('unitprice_input').value) || 0;
    document.getElementById('total_input').value = (qty * up).toFixed(2);
}

document.addEventListener('DOMContentLoaded', function () {
    const input    = document.getElementById('part_input');
    const dropdown = document.getElementById('parts_dropdown');

    function renderDropdown(items) {
        dropdown.innerHTML = '';
        if (!items.length) { dropdown.classList.add('hidden'); return; }
        items.forEach(function(item) {
            const div = document.createElement('div');
            div.textContent = item;
            div.className = 'px-3 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 cursor-pointer border-b border-gray-50 last:border-0';
            div.addEventListener('mousedown', function(e) {
                e.preventDefault();
                input.value = item;
                dropdown.classList.add('hidden');
            });
            dropdown.appendChild(div);
        });
        dropdown.classList.remove('hidden');
    }

    input.addEventListener('input', function () {
        const q = this.value.toLowerCase().trim();
        if (!q) { renderDropdown(partsList.slice(0, 20)); return; }
        const filtered = partsList.filter(function(p) { return p.toLowerCase().includes(q); }).slice(0, 20);
        renderDropdown(filtered);
    });

    input.addEventListener('focus', function () {
        const q = this.value.toLowerCase().trim();
        const items = q ? partsList.filter(function(p) { return p.toLowerCase().includes(q); }).slice(0, 20) : partsList.slice(0, 20);
        renderDropdown(items);
    });

    input.addEventListener('blur', function () {
        setTimeout(function() { dropdown.classList.add('hidden'); }, 150);
    });

    document.querySelectorAll('.delete-item-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (!confirm('Delete this item?')) return;
            var postData = { _token: document.querySelector('meta[name=csrf-token]').content, Pid: this.dataset.id };
            fetch('<?php echo e(route("jobcard.delete-item")); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams(postData)
            }).then(function () { location.reload(); });
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/service/jobcard/additional-part.blade.php ENDPATH**/ ?>