<?php $__env->startSection('title', 'New Jobber - Parts'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h2 class="text-2xl font-bold text-gray-800">Add New Jobber / Vendor</h2>
</div>
<?php if(session('success')): ?><div class="mb-4 p-4 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-700 rounded-r-xl"><?php echo e(session('success')); ?></div><?php endif; ?>
<?php if(session('error')): ?><div class="mb-4 p-4 bg-rose-50 border-l-4 border-rose-500 text-rose-700 rounded-r-xl"><?php echo e(session('error')); ?></div><?php endif; ?>
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
<div class="bg-white rounded shadow-sm border border-gray-200 p-6">
<form action="<?php echo e(route('parts.new-jobber.store')); ?>" method="POST">
<?php echo csrf_field(); ?>
<div class="space-y-4">
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Jobber Name <span class="text-red-500">*</span></label>
        <input type="text" name="jobber" required class="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:ring-2 focus:ring-red-500">
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Type</label>
        <select name="cust_jobber" class="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:ring-2 focus:ring-red-500">
            <option value="Jobber">Jobber</option>
            <option value="Customer">Customer</option>
        </select>
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Contact Person</label>
        <input type="text" name="contactperson" class="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:ring-2 focus:ring-red-500">
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Contact Number</label>
        <input type="text" name="contact" class="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:ring-2 focus:ring-red-500">
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Address</label>
        <input type="text" name="address" class="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:ring-2 focus:ring-red-500">
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
        <input type="email" name="email" class="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:ring-2 focus:ring-red-500">
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">CNIC</label>
        <input type="text" name="CNIC" class="w-full border border-gray-300 rounded px-3 py-2.5 text-sm focus:ring-2 focus:ring-red-500">
    </div>
</div>
<div class="mt-6">
    <button type="submit" class="w-full bg-red-600 text-white py-2.5 rounded font-medium hover:bg-red-700 transition-all">Add Jobber</button>
</div>
</form>
</div>
<div class="bg-white rounded shadow-sm border border-gray-200 overflow-hidden">
    <div class="p-4 border-b border-gray-100"><h3 class="font-semibold text-gray-800">Existing Jobbers</h3></div>
    <div class="overflow-y-auto max-h-96">
    <table class="w-full text-sm">
        <thead class="bg-gray-50"><tr>
            <th class="px-4 py-2 text-left text-xs text-gray-500">Name</th>
            <th class="px-4 py-2 text-left text-xs text-gray-500">Contact</th>
            <th class="px-4 py-2 text-right text-xs text-gray-500">Balance</th>
        </tr></thead>
        <tbody class="divide-y divide-gray-50">
        <?php $__currentLoopData = $jobbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="hover:bg-red-50/30">
            <td class="px-4 py-2 font-medium text-gray-800"><?php echo e($j->jbr_name); ?></td>
            <td class="px-4 py-2 text-gray-500 text-xs"><?php echo e($j->contact); ?></td>
            <td class="px-4 py-2 text-right <?php echo e($j->Balance_status < 0 ? 'text-red-600' : 'text-green-600'); ?>"><?php echo e(number_format($j->Balance_status ?? 0, 2)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\3spro\resources\views/parts/entry/new_jobber.blade.php ENDPATH**/ ?>