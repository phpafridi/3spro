<?php $__env->startSection('title', 'Sales - Unclose Jobcards'); ?>
<?php $__env->startSection('sidebar-menu'); ?> <?php echo $__env->make('sales.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded shadow-sm p-6">
    <div class="flex items-center mb-4">
        <h2 class="text-xl font-semibold text-gray-800">Unclosed Jobcards
            <span class="ml-2 px-2 py-0.5 bg-red-100 text-red-700 text-sm rounded-full"><?php echo e(count($jobcards)); ?></span>
        </h2>
    </div>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-red-600"><tr>
                <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Jobcard#</th>
                <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Registration</th>
                <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Customer</th>
                <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">SA</th>
                <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Open Time</th>
                <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Labor Status</th>
                <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Status</th>
            </tr></thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $jobcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $hrs = \Carbon\Carbon::parse($jc->Open_date_time)->diffInHours(now()); ?>
                <tr class="hover:bg-gray-50 <?php echo e($hrs > 48 ? 'bg-red-50' : ($hrs > 24 ? 'bg-yellow-50' : '')); ?>">
                    <td class="px-4 py-3 text-sm font-bold text-gray-900">#<?php echo e($jc->Jobc_id); ?></td>
                    <td class="px-4 py-3 text-sm font-medium text-red-600"><?php echo e($jc->Veh_reg_no); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($jc->Customer_name); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($jc->SA); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($jc->bookingtime); ?></td>
                    <td class="px-4 py-3 text-sm">
                        <?php if($jc->openLabors > 0): ?>
                            <span class="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs rounded-full"><?php echo e($jc->openLabors); ?> Open</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full">All Done</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 text-sm">
                        <?php if($jc->status=='0'): ?>
                            <span class="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs rounded-full">Open</span>
                        <?php elseif($jc->status=='1'): ?>
                            <span class="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full">In Workshop</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full">Status <?php echo e($jc->status); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-6 py-8 text-center text-green-600">
                    <i class="fa fa-check-circle mr-1"></i>All jobcards closed!
                </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\3spro\resources\views/sales/jobcards.blade.php ENDPATH**/ ?>