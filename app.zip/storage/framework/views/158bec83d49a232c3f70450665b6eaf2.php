<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Sale Return SRJV #<?php echo e($invoice_no); ?></title>
<style>body{font-family:Arial,sans-serif;font-size:12px;margin:20px}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #ccc;padding:6px 10px}th{background:#f0f0f0}@media print{button{display:none}}</style>
</head><body>
<h2>Sale Return - SRJV #<?php echo e($invoice_no); ?></h2>
<table><thead><tr><th>#</th><th>Invoice No</th><th>Sell ID</th><th>Stock ID</th><th>Unit Price</th><th>Return Qty</th><th>Return By</th><th>Reason</th><th>Date</th></tr></thead>
<tbody><?php $__currentLoopData = $return; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($i+1); ?></td><td><?php echo e($r->invoice_no); ?></td><td><?php echo e($r->sell_id); ?></td><td><?php echo e($r->stock_id); ?></td><td><?php echo e(number_format($r->unit_price,2)); ?></td><td><?php echo e($r->return_qty); ?></td><td><?php echo e($r->return_by); ?></td><td><?php echo e($r->reason); ?></td><td><?php echo e($r->datetime ?? '-'); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table>
<br><button onclick="window.print()">Print</button>
</body></html>
<?php /**PATH C:\xampp\htdocs\3spro\resources\views/parts/entry/sale/files/print_sale_return.blade.php ENDPATH**/ ?>