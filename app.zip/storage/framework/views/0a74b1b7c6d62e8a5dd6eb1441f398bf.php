<?php $__env->startSection('title', 'Status — Labor'); ?>
<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('service.partials.jobcard-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Labor Status</h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-red-600">
                <tr>
                    <th class="px-3 py-2 text-left text-xs font-medium text-white uppercase">RO#</th>
                    <th class="px-3 py-2 text-left text-xs font-medium text-white uppercase">Registration</th>
                    <th class="px-3 py-2 text-left text-xs font-medium text-white uppercase">Labor</th>
                    <th class="px-3 py-2 text-left text-xs font-medium text-white uppercase">Bay</th>
                    <th class="px-3 py-2 text-left text-xs font-medium text-white uppercase">Team</th>
                    <th class="px-3 py-2 text-left text-xs font-medium text-white uppercase">Cost</th>
                    <th class="px-3 py-2 text-left text-xs font-medium text-white uppercase">Status</th>
                    <th class="px-3 py-2 text-left text-xs font-medium text-white uppercase">Added</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                
                <?php $__empty_1 = true; $__currentLoopData = $labors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-3 py-2 text-sm font-bold">#<?php echo e($l->Jobc_id); ?></td>
                    <td class="px-3 py-2 text-sm text-red-600"><?php echo e($l->Registration); ?></td>
                    <td class="px-3 py-2 text-sm"><?php echo e($l->Labor); ?></td>
                    <td class="px-3 py-2 text-sm text-red-600"><?php echo e($l->bay); ?></td>
                    <td class="px-3 py-2 text-sm text-red-600"><?php echo e($l->team); ?></td>
                    
                    <td class="px-3 py-2 text-sm"><?php echo e(number_format($l->cost, 0)); ?></td>
                    <td class="px-3 py-2 text-sm">
                        <?php if($l->status == 'Jobclose'): ?>
                            <span class="px-2 py-0.5 bg-green-100 text-green-800 rounded text-xs">Done</span>
                        <?php elseif($l->status == '1'): ?>
                            <span class="px-2 py-0.5 bg-blue-100 text-blue-800 rounded text-xs">Assigned</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded text-xs">Pending</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-3 py-2 text-xs text-gray-500">
                        <?php echo e($l->entry_time ? \Carbon\Carbon::parse($l->entry_time)->format('d/m/Y g:i A') : '—'); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-6 py-8 text-center text-gray-400">No labor items found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/service/jobcard/status-labor.blade.php ENDPATH**/ ?>