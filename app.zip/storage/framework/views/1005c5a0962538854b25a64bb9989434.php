<?php $__env->startSection('title', 'RO #<?php echo e($jobcId); ?> — Vehicle Checklist'); ?>
<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('service.partials.jobcard-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('vin_warning')): ?>
<div class="mb-4 p-4 bg-yellow-50 border border-yellow-400 rounded-md text-yellow-800 font-semibold text-sm">
    <i class="fa fa-exclamation-triangle mr-2"></i>
    <?php echo e(session('vin_warning')); ?>

</div>
<?php endif; ?>

<div class="max-w-3xl mx-auto">
    <div class="bg-white rounded shadow-sm p-6">
        <h2 class="text-xl font-semibold text-gray-800 mb-2">
            RO# <span class="text-red-600"><?php echo e($jobcId); ?></span> — Vehicle Items Checklist
        </h2>
        <p class="text-sm text-gray-500 mb-6">
            Check which items are present in / with the vehicle at time of check-in.
        </p>

        <form action="<?php echo e(route('jobcard.checklist.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="jobc_id" value="<?php echo e($jobcId); ?>">

            <div class="grid grid-cols-2 md:grid-cols-3 gap-3 mb-8">
                <?php
                $items = [
                    'USB'             => ['label' => 'USB Flash Drive',    'default' => false],
                    'Reader'          => ['label' => 'Card Reader',         'default' => false],
                    'AshTray'         => ['label' => 'Ash Tray',            'default' => true],
                    'Lighter'         => ['label' => 'Lighter',             'default' => true],
                    'WiperBlades'     => ['label' => 'Wiper Blades',        'default' => false],
                    'SeatCovers'      => ['label' => 'Seat Covers',         'default' => false],
                    'DickeyMat'       => ['label' => 'Dickey Mat',          'default' => false],
                    'SpareWheel'      => ['label' => 'Spare Wheel',         'default' => true],
                    'JackHandle'      => ['label' => 'Jack Handle',         'default' => true],
                    'Tools'           => ['label' => 'Tools',               'default' => true],
                    'Perfume'         => ['label' => 'Perfume',             'default' => false],
                    'Remote'          => ['label' => 'Any Remote',          'default' => true],
                    'FloorMats'       => ['label' => 'Floor Mats',          'default' => true],
                    'RearViewMirrors' => ['label' => 'Rear View Mirrors',   'default' => true],
                    'Cassettes'       => ['label' => 'Cassettes / CDs',     'default' => false],
                    'Hubcaps'         => ['label' => 'Hub Caps',            'default' => true],
                    'Wheelcaps'       => ['label' => 'Wheel Caps',          'default' => true],
                    'Monograms'       => ['label' => 'Monograms',           'default' => false],
                    'Noofkeys'        => ['label' => 'Keys',                'default' => false],
                    'RadioAntenna'    => ['label' => 'Radio Antenna',       'default' => true],
                    'Clock'           => ['label' => 'Clock',               'default' => true],
                    'Nav_sys'         => ['label' => 'Navigation System',   'default' => false],
                ];
                ?>

                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center gap-2 p-3 border border-gray-200 rounded-md cursor-pointer hover:bg-green-50 has-[:checked]:border-green-400 has-[:checked]:bg-green-50 transition-colors">
                    <input type="checkbox" name="<?php echo e($name); ?>"
                           <?php echo e($item['default'] ? 'checked' : ''); ?>

                           class="h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500">
                    <span class="text-sm text-gray-700"><?php echo e($item['label']); ?></span>
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="text-center">
                <button type="submit"
                        class="px-10 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-md transition-colors">
                    <i class="fa fa-check mr-2"></i> Submit &amp; Open RO
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\3spro\resources\views/service/jobcard/checklist.blade.php ENDPATH**/ ?>