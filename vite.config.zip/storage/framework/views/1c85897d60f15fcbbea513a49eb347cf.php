<?php echo $__env->make('finance.recovery.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Recovery - Manage Accounts'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6 max-w-3xl">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-university text-indigo-500 mr-2"></i>Manage Recovery Accounts
    </h2>

    
    
    <form method="POST" action="<?php echo e(route('recovery.add-account.store')); ?>" class="mb-8 p-5 bg-indigo-50 border border-indigo-200 rounded-xl">
        <?php echo csrf_field(); ?>
        <h3 class="text-sm font-semibold text-indigo-700 mb-4"><i class="fas fa-plus-circle mr-1"></i>Add New Account</h3>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Full Name <span class="text-red-500">*</span></label>
                <input type="text" name="Name" required maxlength="38"
                       class="w-full border border-gray-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-400"
                       placeholder="Customer / company name">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Occupation</label>
                <input type="text" name="Occopation" maxlength="30"
                       class="w-full border border-gray-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-400"
                       placeholder="e.g. Businessman">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Primary Contact <span class="text-red-500">*</span></label>
                <input type="number" name="Primary_contact" required
                       class="w-full border border-gray-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-400"
                       placeholder="03xxxxxxxxx">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Secondary Contact</label>
                <input type="number" name="Sec_contact"
                       class="w-full border border-gray-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-400"
                       placeholder="Optional">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Email</label>
                <input type="email" name="email" maxlength="50"
                       class="w-full border border-gray-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-400">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Credit Limit (Rs)</label>
                <input type="number" name="amount_limit" value="0"
                       class="w-full border border-gray-300 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-400">
            </div>
        </div>
        <button type="submit" class="mt-4 px-5 py-2 bg-indigo-600 text-white rounded-xl text-sm font-medium hover:bg-indigo-700 transition">
            <i class="fas fa-save mr-2"></i>Save Account
        </button>
    </form>

    
    <h3 class="font-semibold text-gray-700 mb-3 text-sm uppercase tracking-wider">Existing Accounts</h3>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-indigo-600 to-purple-600">
                <tr>
                    <?php $__currentLoopData = ['#','Name','Occupation','Primary Contact','Credit Limit','Officer','Status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($h); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 text-gray-400"><?php echo e($i+1); ?></td>
                    <td class="px-4 py-3 font-medium"><?php echo e($a->Name); ?></td>
                    <td class="px-4 py-3 text-xs text-gray-500"><?php echo e($a->Occopation); ?></td>
                    <td class="px-4 py-3 font-mono"><?php echo e(number_format($a->Primary_contact)); ?></td>
                    <td class="px-4 py-3 font-semibold text-indigo-600">Rs <?php echo e(number_format($a->amount_limit)); ?></td>
                    <td class="px-4 py-3 text-xs text-gray-500"><?php echo e($a->r_officer); ?></td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-0.5 rounded-full text-xs
                            <?php echo e($a->status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'); ?>">
                            <?php echo e($a->status); ?>

                        </span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-4 py-8 text-center text-gray-400">No accounts added yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/recovery/add_account.blade.php ENDPATH**/ ?>