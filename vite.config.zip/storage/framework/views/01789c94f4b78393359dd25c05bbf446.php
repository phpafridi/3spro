<?php echo $__env->make('finance.recovery.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Non-Active Accounts'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-bell-slash text-orange-500 mr-2"></i> Non-Active Accounts (No Followup in 7 Days)
    </h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-orange-500 to-red-500">
                <tr>
                    <?php $__currentLoopData = ['#','Customer','Contact','Last Followup','Actions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($h); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 text-gray-400"><?php echo e($loop->iteration); ?></td>
                    <td class="px-4 py-3 font-medium">
                        <a href="<?php echo e(route('recovery.customer-ledger', ['id'=>$r->cust_name])); ?>" class="text-indigo-600 hover:underline"><?php echo e($r->cust_name); ?></a>
                    </td>
                    <td class="px-4 py-3"><?php echo e($r->contact); ?></td>
                    <td class="px-4 py-3 text-xs text-gray-400"><?php echo e($r->last_fol ?? 'Never'); ?></td>
                    <td class="px-4 py-3">
                        <a href="<?php echo e(route('recovery.followup', ['id'=>$r->cust_name])); ?>"
                           class="px-3 py-1 bg-green-100 text-green-700 rounded-lg text-xs hover:bg-green-200">Add Followup</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="px-4 py-8 text-center text-green-500 font-medium">All accounts are active!</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/recovery/not_contacted.blade.php ENDPATH**/ ?>