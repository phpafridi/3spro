<?php echo $__env->make('finance.accountant.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Labor Requests'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-clipboard-list text-indigo-500 mr-2"></i> Labor Requests
    </h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-indigo-600 to-purple-600">
                <tr>
                    <?php $__currentLoopData = ['#','Labor','Cat1','Cat2','Cat3','Cat4','Cat5','Remarks','Requested By','Requested On','Action']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-3 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($h); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-3 py-3"><?php echo e($loop->iteration); ?></td>
                    <td class="px-3 py-3 font-medium"><?php echo e($r->labor); ?></td>
                    <td class="px-3 py-3"><?php echo e($r->cate1); ?></td>
                    <td class="px-3 py-3"><?php echo e($r->cate2); ?></td>
                    <td class="px-3 py-3"><?php echo e($r->cate3); ?></td>
                    <td class="px-3 py-3"><?php echo e($r->cate4); ?></td>
                    <td class="px-3 py-3"><?php echo e($r->cate5); ?></td>
                    <td class="px-3 py-3"><?php echo e($r->remarks); ?></td>
                    <td class="px-3 py-3"><?php echo e($r->who_req); ?></td>
                    <td class="px-3 py-3 text-xs text-gray-500"><?php echo e($r->when_req); ?></td>
                    <td class="px-3 py-3 flex gap-2">
                        <form method="POST" action="<?php echo e(route('accountant.labor-request.process')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="req_id" value="<?php echo e($r->req_id); ?>">
                            <input type="hidden" name="addto_list" value="1">
                            <button class="px-3 py-1 bg-green-500 hover:bg-green-600 text-white text-xs rounded-lg">Accept</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('accountant.labor-request.process')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="req_id" value="<?php echo e($r->req_id); ?>">
                            <input type="hidden" name="rejected" value="1">
                            <button class="px-3 py-1 bg-red-500 hover:bg-red-600 text-white text-xs rounded-lg">Reject</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="11" class="px-4 py-8 text-center text-gray-400">No pending requests.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/accountant/labor_request.blade.php ENDPATH**/ ?>