<?php $__env->startSection('title', 'Estimates - Parts'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h2 class="text-2xl font-bold text-gray-800">Estimates</h2>
</div>
<div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
<table class="w-full text-sm">
    <thead class="bg-indigo-50"><tr>
        <th class="px-4 py-3 text-left text-xs text-gray-600 uppercase">Est #</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600 uppercase">Registration</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600 uppercase">Variant</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600 uppercase">Type</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600 uppercase">Cust Type</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600 uppercase">Payment</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600 uppercase">Date</th>
        <th class="px-4 py-3 text-left text-xs text-gray-600 uppercase">By</th>
    </tr></thead>
    <tbody class="divide-y divide-gray-100">
    <?php $__empty_1 = true; $__currentLoopData = $estimates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="hover:bg-indigo-50/30">
        <td class="px-4 py-3 font-medium"><?php echo e($e->est_id); ?></td>
        <td class="px-4 py-3"><?php echo e($e->Registration ?? '-'); ?></td>
        <td class="px-4 py-3"><?php echo e($e->Variant ?? '-'); ?></td>
        <td class="px-4 py-3"><?php echo e($e->estimate_type ?? '-'); ?></td>
        <td class="px-4 py-3"><?php echo e($e->cust_type ?? '-'); ?></td>
        <td class="px-4 py-3"><?php echo e($e->payment_mode ?? '-'); ?></td>
        <td class="px-4 py-3 text-xs text-gray-500">
            <?php echo e($e->entry_datetime ? \Carbon\Carbon::parse($e->entry_datetime)->format('d M h:i A') : '-'); ?>

        </td>
        <td class="px-4 py-3 text-xs text-gray-500"><?php echo e($e->user ?? '-'); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="8" class="px-4 py-10 text-center text-gray-400">No estimates found</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/parts/entry/estimates.blade.php ENDPATH**/ ?>