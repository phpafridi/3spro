<?php $__env->startSection('title', 'Search - Parts'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h2 class="text-2xl font-bold text-gray-800">Search & Print</h2>
</div>
<?php if(session('error')): ?><div class="mb-4 p-4 bg-rose-50 border-l-4 border-rose-500 text-rose-700 rounded-r-xl"><?php echo e(session('error')); ?></div><?php endif; ?>
<div class="max-w-xl">
<div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
<form action="<?php echo e(route('parts.search.redirect')); ?>" method="POST">
<?php echo csrf_field(); ?>
<div class="space-y-4">
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Search Type <span class="text-red-500">*</span></label>
        <select name="field" required class="w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500">
            <option value="">-- Select Type --</option>
            <option value="counter-sale">Counter Sale Invoice</option>
            <option value="purch-inv">Purchase Invoice</option>
            <option value="purch-inv-tax">Purchase Invoice (With Tax)</option>
            <option value="PRJV">Purchase Return (PRJV)</option>
            <option value="SRJV">Sale Return (SRJV)</option>
            <option value="WPR">Workshop Parts Return (WPR)</option>
            <option value="Payment">Vendor Payment</option>
        </select>
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Invoice / Reference Number <span class="text-red-500">*</span></label>
        <input type="text" name="search" required
               class="w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" placeholder="Enter number...">
    </div>
</div>
<div class="mt-6">
    <button type="submit" class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2.5 rounded-xl font-medium hover:from-indigo-700 hover:to-purple-700 transition-all">
        <i class="fa fa-search mr-2"></i>Search & Print
    </button>
</div>
</form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/parts/entry/search.blade.php ENDPATH**/ ?>