<?php $__env->startSection('title', 'SM - Labor Status'); ?>
<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('service.partials.sm-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-semibold text-gray-800">Labor Status — In Workshop</h2>
    <a href="<?php echo e(route('sm.index')); ?>" class="px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white text-sm rounded transition-colors"><i class="fa fa-home mr-1"></i>Dashboard</a>
</div>
<?php if($jobcards->isEmpty()): ?>
    <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg"><i class="fa fa-check-circle mr-2"></i>No jobcards currently in workshop.</div>
<?php else: ?>
    <?php $__currentLoopData = $jobcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-lg shadow-sm p-5 mb-4">
        <div class="flex items-center gap-4 mb-3 pb-3 border-b border-gray-100">
            <span class="font-bold text-gray-800">RO# <?php echo e($jc->Jobc_id); ?></span>
            <span class="text-gray-500 text-sm">SA: <?php echo e($jc->SA); ?></span>
            <span class="text-gray-400 text-sm"><?php echo e(\Carbon\Carbon::parse($jc->Open_date_time)->format('d/m/Y g:i A')); ?></span>
        </div>
        <?php if(isset($laborData[$jc->Jobc_id]) && count($laborData[$jc->Jobc_id])): ?>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">#</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Labor</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Cost</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Team</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Bay</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Entry</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $laborData[$jc->Jobc_id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($l->Labor_id); ?></td>
                        <td class="px-4 py-2 text-sm font-medium text-gray-800"><?php echo e($l->Labor); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($l->type); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-700"><?php echo e(number_format($l->cost,0)); ?></td>
                        <td class="px-4 py-2 text-sm">
                            <?php $st = $l->status; ?>
                            <?php if(!$st): ?><span class="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full">Pending</span>
                            <?php elseif($st=='Job Assign'): ?><span class="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full">Assigned</span>
                            <?php elseif($st=='Jobclose'): ?><span class="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full">Done</span>
                            <?php elseif($st=='Job Stopage'): ?><span class="px-2 py-0.5 bg-red-100 text-red-700 text-xs rounded-full">Stopped</span>
                            <?php elseif($st=='Job Not Done'): ?><span class="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs rounded-full">Not Done</span>
                            <?php else: ?><span class="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full"><?php echo e($st); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($l->team); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($l->bay); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-400"><?php echo e($l->entry_time); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
            <p class="text-gray-400 text-sm italic">No labor added yet.</p>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/service/sm/status-labor.blade.php ENDPATH**/ ?>