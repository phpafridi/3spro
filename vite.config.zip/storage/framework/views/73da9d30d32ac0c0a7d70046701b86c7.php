<?php $__env->startSection('title', 'SM - Insurance Companies'); ?>
<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('service.partials.sm-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?><div class="mb-4 p-3 bg-green-100 text-green-800 rounded-md"><?php echo e(session('success')); ?></div><?php endif; ?>
<div class="grid grid-cols-1 md:grid-cols-5 gap-6">
    <div class="md:col-span-2 bg-white rounded-lg shadow-sm p-6">
        <h2 class="text-lg font-semibold text-gray-800 mb-4">Add Insurance Company</h2>
        <form method="POST" action="<?php echo e(route('sm.insurance.store')); ?>" class="space-y-3">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = ['jobber'=>'Company Name *','contactperson'=>'Contact Person','contact'=>'Contact','email'=>'Email','address'=>'Address','ntn'=>'NTN']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e($label); ?></label>
                <input type="text" name="<?php echo e($name); ?>" <?php echo e(str_contains($label,'*') ? 'required' : ''); ?>

                       class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" class="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md transition-colors">
                <i class="fa fa-plus mr-2"></i> Add
            </button>
        </form>
    </div>
    <div class="md:col-span-3 bg-white rounded-lg shadow-sm p-6">
        <h2 class="text-lg font-semibold text-gray-800 mb-4">Insurance Companies
            <span class="ml-2 px-2 py-0.5 bg-gray-100 text-gray-600 text-sm rounded-full"><?php echo e($companies->count()); ?></span>
        </h2>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Contact</th>
                        <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-3 py-2 text-sm font-medium text-gray-800"><?php echo e($v->company_name); ?></td>
                        <td class="px-3 py-2 text-sm text-gray-500"><?php echo e($v->contact); ?></td>
                        <td class="px-3 py-2 text-sm text-gray-500"><?php echo e($v->email); ?></td>
                        <td class="px-3 py-2 text-sm">
                            <?php if($v->status=='Active'): ?><span class="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full">Active</span>
                            <?php else: ?><span class="px-2 py-0.5 bg-gray-100 text-gray-500 text-xs rounded-full">Suspended</span><?php endif; ?>
                        </td>
                        <td class="px-3 py-2">
                            <form method="POST" action="<?php echo e(route('sm.insurance.toggle')); ?>" class="inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="c_id" value="<?php echo e($v->c_id); ?>">
                                <input type="hidden" name="action" value="<?php echo e($v->status=='Active'?'suspend':'activate'); ?>">
                                <button type="submit" class="px-2 py-1 <?php echo e($v->status=='Active' ? 'bg-yellow-500 hover:bg-yellow-600' : 'bg-green-600 hover:bg-green-700'); ?> text-white text-xs rounded transition-colors">
                                    <?php echo e($v->status=='Active' ? 'Suspend' : 'Activate'); ?>

                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="px-4 py-6 text-center text-gray-400">No insurance companies.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/service/sm/insurance.blade.php ENDPATH**/ ?>