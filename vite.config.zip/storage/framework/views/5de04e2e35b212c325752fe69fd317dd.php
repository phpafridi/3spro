<?php echo $__env->make('finance.accounts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Accounts - Pending Vouchers'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-2xl font-semibold text-gray-800">
            <i class="fas fa-clock text-yellow-500 mr-2"></i>Pending Vouchers
        </h2>
        <span class="bg-yellow-100 text-yellow-800 text-xs font-semibold px-3 py-1 rounded-full">
            <?php echo e(count($vouchers)); ?> Pending
        </span>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-yellow-500 to-orange-500">
                <tr>
                    <?php $__currentLoopData = ['#','Type','Ref No','Date','Book No','Created By','Action']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($h); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3"><?php echo e($i+1); ?></td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-1 rounded-full text-xs font-semibold
                            <?php echo e(in_array($v->vchr_type,['CPV','CRV']) ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'); ?>">
                            <?php echo e($v->vchr_type); ?>

                        </span>
                    </td>
                    <td class="px-4 py-3 font-mono"><?php echo e($v->RefNo); ?></td>
                    <td class="px-4 py-3 text-xs text-gray-600"><?php echo e($v->VoucherDate); ?></td>
                    <td class="px-4 py-3"><?php echo e($v->BookNo); ?></td>
                    <td class="px-4 py-3"><?php echo e($v->UserName); ?></td>
                    <td class="px-4 py-3 flex gap-2">
                        
                        <form method="POST" action="<?php echo e(route('accounts.pending-vouchers')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="Submitit" value="<?php echo e($v->mas_vch_id); ?>">
                            <button class="px-3 py-1 bg-green-500 text-white rounded-lg text-xs hover:bg-green-600">
                                <i class="fas fa-paper-plane mr-1"></i>Submit
                            </button>
                        </form>
                        
                        <form method="POST" action="<?php echo e(route('accounts.pending-vouchers')); ?>"
                              onsubmit="return confirm('Trash this voucher?')">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="vch_status_cancel" value="<?php echo e($v->mas_vch_id); ?>">
                            <button class="px-3 py-1 bg-red-500 text-white rounded-lg text-xs hover:bg-red-600">
                                <i class="fas fa-trash mr-1"></i>Trash
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-4 py-8 text-center text-gray-400">No pending vouchers</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/accounts/pending_vouchers.blade.php ENDPATH**/ ?>