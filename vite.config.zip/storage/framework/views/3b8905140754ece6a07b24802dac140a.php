<?php echo $__env->make('finance.accountant.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Parts Reports'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-wpforms text-indigo-500 mr-2"></i> Parts Department Reports
    </h2>
    <div class="mb-6">
        <input type="text" id="parts_reservation" class="border border-gray-300 rounded-lg px-3 py-2 text-sm w-72"
            value="<?php echo e(date('m/d/Y')); ?> - <?php echo e(date('m/d/Y')); ?>">
    </div>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
        <?php $__currentLoopData = ['Parts Sales Report','Purchase Report','Stock Report','Parts Difference','Labor Detail','Purchase Profile','Parts Price Change','Parts Cancel Report']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('parts.reports')); ?>"
            class="px-4 py-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 text-sm font-medium">
            <i class="fas fa-file-alt mr-2"></i><?php echo e($r); ?>

        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">
<script src="https://cdn.jsdelivr.net/npm/moment/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script>$('#parts_reservation').daterangepicker();</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/accountant/parts_reports.blade.php ENDPATH**/ ?>