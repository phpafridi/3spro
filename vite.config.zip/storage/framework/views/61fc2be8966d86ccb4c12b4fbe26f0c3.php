<?php echo $__env->make('finance.accountant.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Labor List - Manual'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-edit text-indigo-500 mr-2"></i> Labor List (Manual Edit)
    </h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-indigo-600 to-purple-600">
                <tr>
                    <?php $__currentLoopData = ['#','Labor','Cat1','Cat2','Cat3','Cat4','Cat5']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($h); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $labors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 text-gray-500"><?php echo e($loop->iteration); ?></td>
                    <td class="px-4 py-3 font-medium"><?php echo e($l->Labor); ?></td>
                    <td class="px-4 py-3"><?php echo e(number_format($l->Cate1)); ?></td>
                    <td class="px-4 py-3"><?php echo e(number_format($l->Cate2)); ?></td>
                    <td class="px-4 py-3"><?php echo e(number_format($l->Cate3)); ?></td>
                    <td class="px-4 py-3"><?php echo e(number_format($l->Cate4)); ?></td>
                    <td class="px-4 py-3"><?php echo e(number_format($l->Cate5)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-4 py-8 text-center text-gray-400">No labor entries found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/accountant/labor_manual.blade.php ENDPATH**/ ?>