<?php echo $__env->make('finance.accountant.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Reopen Jobcard'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-undo text-indigo-500 mr-2"></i> Reopen JC Requests
    </h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-indigo-600 to-purple-600">
                <tr>
                    <?php $__currentLoopData = ['#','JC ID','SM Reason','Requested By','SM Date','Action']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($h); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3"><?php echo e($loop->iteration); ?></td>
                    <td class="px-4 py-3 font-mono font-bold"><?php echo e($r->jobc_id); ?></td>
                    <td class="px-4 py-3"><?php echo e($r->SM_reason); ?></td>
                    <td class="px-4 py-3"><?php echo e($r->SM); ?></td>
                    <td class="px-4 py-3"><?php echo e($r->sm_datetime); ?></td>
                    <td class="px-4 py-3 flex gap-2">
                        
                        <form method="POST" action="<?php echo e(route('accountant.reopen-jc.process')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="Jobc_id" value="<?php echo e($r->jobc_id); ?>">
                            <input type="hidden" name="unjc_Id" value="<?php echo e($r->unjc_Id); ?>">
                            <button class="px-3 py-1 bg-green-500 hover:bg-green-600 text-white text-xs rounded-lg">Approve</button>
                        </form>
                        
                        <form method="POST" action="<?php echo e(route('accountant.reopen-jc.process')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="unclose_id" value="<?php echo e($r->unjc_Id); ?>">
                            <button class="px-3 py-1 bg-red-500 hover:bg-red-600 text-white text-xs rounded-lg">Reject</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="px-4 py-8 text-center text-gray-400">No pending reopen requests.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/accountant/reopen_jc.blade.php ENDPATH**/ ?>