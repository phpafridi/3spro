<?php echo $__env->make('finance.recovery.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Add Credit Entry'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6 max-w-xl">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-plus-circle text-green-500 mr-2"></i> Credit Entry Form
    </h2>
    <form method="POST" action="<?php echo e(route('recovery.add-credit.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">DM Invoice No</label>
                <input type="text" name="required_dm" required value="<?php echo e($prefill->dm_invoice ?? ($prefill->Invoice_no ?? '')); ?>"
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Payment Method</label>
                <select name="required_payment_method" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                    <option value="">-- Select --</option>
                    <?php $__currentLoopData = ['Cash','Cheque','Online Transfer','IBFT','Bank Draft']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($m); ?>" <?php echo e(isset($prefill->Payment_method) && $prefill->Payment_method==$m ? 'selected':''); ?>><?php echo e($m); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">RT / Reference No</label>
                <input type="text" name="required_rt" value="<?php echo e($prefill->RT_no ?? ''); ?>"
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input type="date" name="required_date" required value="<?php echo e($prefill->cr_date ?? date('Y-m-d')); ?>"
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Amount (Rs)</label>
                <input type="number" name="required_amount" required value="<?php echo e($prefill->cr_amount ?? ''); ?>"
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Remarks</label>
                <textarea name="remarks" rows="2" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm"><?php echo e($prefill->remarks ?? ''); ?></textarea>
            </div>
        </div>
        <button type="submit" class="mt-6 px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-xl font-medium">
            Add Credit Entry
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/recovery/add_cred.blade.php ENDPATH**/ ?>