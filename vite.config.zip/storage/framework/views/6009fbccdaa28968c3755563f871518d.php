<?php echo $__env->make('finance.recovery.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Recovery - Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="grid grid-cols-3 md:grid-cols-6 gap-4 mb-6">
    <?php $__currentLoopData = [
        ['Total',   $totalc,    'bg-indigo-500'],
        ['New',     $new,       'bg-sky-500'],
        ['Open',    $open,      'bg-orange-500'],
        ['Close',   $close,     'bg-green-500'],
        ['Active',  $active,    'bg-yellow-500'],
        ['Pending', $pending,   'bg-red-500'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $val, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-2xl shadow-sm p-4 text-center">
        <div class="text-2xl font-bold text-gray-800"><?php echo e($val); ?></div>
        <div class="text-xs text-gray-500 mt-1"><?php echo e($label); ?></div>
        <div class="<?php echo e($color); ?> h-1 rounded-full mt-2 opacity-60"></div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="bg-gradient-to-r from-red-500 to-rose-600 text-white rounded-2xl p-4 mb-6 text-center">
    <p class="text-sm opacity-80">Total Outstanding Debit</p>
    <p class="text-3xl font-bold mt-1">Rs <?php echo e(number_format($totalDebit)); ?></p>
</div>


<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-lg font-semibold text-gray-800 mb-4">Outstanding Accounts</h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-red-600 to-rose-600">
                <tr>
                    <?php $__currentLoopData = ['#','Customer','Contact','Age','Debit Amount','Actions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($h); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $debtors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if(($d->remain_amount ?? 0) > 0): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 text-gray-400"><?php echo e($loop->iteration); ?></td>
                    <td class="px-4 py-3 font-medium">
                        <a href="<?php echo e(route('recovery.customer-ledger', ['id'=>$d->cust_name])); ?>" class="text-indigo-600 hover:underline">
                            <?php echo e($d->cust_name); ?>

                        </a>
                    </td>
                    <td class="px-4 py-3"><?php echo e($d->contact); ?></td>
                    <td class="px-4 py-3 text-xs text-gray-500"><?php echo e($d->age ?? ''); ?></td>
                    <td class="px-4 py-3 font-medium text-red-600">
                        <a href="<?php echo e(route('recovery.clearance', ['id'=>$d->cust_name])); ?>" class="hover:underline">
                            Rs <?php echo e(number_format($d->remain_amount)); ?>

                        </a>
                    </td>
                    <td class="px-4 py-3 flex gap-2">
                        <a href="<?php echo e(route('recovery.history', ['id'=>$d->cust_name])); ?>"
                           class="px-2 py-1 bg-yellow-100 text-yellow-700 rounded text-xs hover:bg-yellow-200">History</a>
                        <a href="<?php echo e(route('recovery.followup', ['id'=>$d->cust_name])); ?>"
                           class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs hover:bg-green-200">Followup</a>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="px-4 py-8 text-center text-gray-400">No debtors found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/recovery/index.blade.php ENDPATH**/ ?>