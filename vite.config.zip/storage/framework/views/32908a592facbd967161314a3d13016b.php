<?php $__env->startSection('title', 'BP - In Progress Jobs'); ?>
<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('service.partials.bp-jc-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?><div class="mb-4 p-3 bg-green-100 text-green-800 rounded-md"><?php echo e(session('success')); ?></div><?php endif; ?>
<form method="POST" action="<?php echo e(route('bp-jc.job-done')); ?>" id="jobDoneForm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="Labor_id" id="done_labor_id">
</form>
<div class="bg-white rounded-lg shadow-sm p-6">
    <div class="flex items-center mb-4">
        <h2 class="text-xl font-semibold text-gray-800">In Progress Jobs
            <span class="ml-2 px-2 py-0.5 bg-blue-100 text-blue-700 text-sm rounded-full"><?php echo e($inprogressJobs->count()); ?></span>
        </h2>
    </div>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">#</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">RO No</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Labor</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Team</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Bay</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Registration</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">SA</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Assign Time</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $inprogressJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition-colors">
                    <td class="px-4 py-3 text-sm text-gray-400"><?php echo e($i+1); ?></td>
                    <td class="px-4 py-3 text-sm font-bold text-gray-900">#<?php echo e($job->RO_no); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($job->Labor); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($job->team); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($job->bay); ?></td>
                    <td class="px-4 py-3 text-sm font-medium text-red-600"><?php echo e($job->Registration); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($job->SA); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($job->Assign_time); ?></td>
                    <td class="px-4 py-3">
                        <button class="done-btn px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-medium rounded-md transition-colors" data-id="<?php echo e($job->Labor_id); ?>">
                            <i class="fa fa-check mr-1"></i> Job Done
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="9" class="px-6 py-8 text-center text-gray-400">No jobs in progress.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
document.querySelectorAll('.done-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        if (!confirm('Mark this job as Done?')) return;
        document.getElementById('done_labor_id').value = this.dataset.id;
        document.getElementById('jobDoneForm').submit();
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/service/bp-jc/inprogress.blade.php ENDPATH**/ ?>