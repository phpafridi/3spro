<?php echo $__env->make('finance.cashier.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startSection('title', 'Cashier - Pending Invoices'); ?>

<?php $__env->startSection('content'); ?>
<!-- Auto-refresh meta tag -->
<meta http-equiv="refresh" content="10">

<div class="bg-white rounded-lg shadow-sm p-6">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-semibold text-gray-800">
            <i class="fas fa-clock text-yellow-500 mr-2"></i>
            Pending Invoices
        </h2>
        <span class="bg-yellow-100 text-yellow-800 text-xs font-medium px-3 py-1 rounded-full">
            <?php echo e(count($pendingInvoices)); ?> Pending
        </span>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gradient-to-r from-blue-600 to-blue-700">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Jobcard#</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Vehicle</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Customer</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Mobile</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">MSI</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Registration</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Clock Off</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">SA</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Action</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $pendingInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition-colors">
                    <td class="px-6 py-4 whitespace-nowrap font-mono text-sm">
                        <a href="<?php echo e(route('cashier.print-initial-ro', ['job_id' => $invoice->Jobc_id])); ?>"
                           target="_blank"
                           class="text-blue-600 hover:text-blue-900">
                            #<?php echo e($invoice->Jobc_id); ?>

                        </a>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e($invoice->Variant); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e($invoice->Customer_name); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e($invoice->mobile); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e($invoice->MSI_cat); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e($invoice->Registration); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        <?php echo e(\Carbon\Carbon::parse($invoice->closing_time)->format('d-M g:i A')); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e($invoice->SA); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <form action="<?php echo e(route('cashier.invoice')); ?>" method="POST" target="_blank">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="job_id" value="<?php echo e($invoice->Jobc_id); ?>">
                            <button type="submit" class="inline-flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-lg transition-colors">
                                <i class="fas fa-file-invoice mr-2"></i> Invoice
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="px-6 py-8 text-center text-gray-500">
                        <i class="fas fa-check-circle text-4xl mb-3 text-green-400"></i>
                        <p>No pending invoices found</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Auto-refresh notification -->
<div class="fixed bottom-4 right-4 bg-blue-100 border border-blue-400 text-blue-700 px-4 py-2 rounded-lg shadow-lg text-sm">
    <i class="fas fa-sync-alt mr-2 animate-spin"></i> Page auto-refreshes every 10 seconds
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/cashier/index.blade.php ENDPATH**/ ?>