<?php $__env->startSection('title', 'DPOK Reports - Parts'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h2 class="text-2xl font-bold text-gray-800">DPOK Reports</h2>
</div>
<div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 text-center text-gray-400">
    <i class="fa fa-line-chart text-4xl mb-3 block text-indigo-300"></i>
    <p class="text-lg font-medium text-gray-600">DPOK Report Module</p>
    <p class="text-sm mt-1">Dealer Parts Order Knowledge reports will be displayed here</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/parts/entry/report_Dpok.blade.php ENDPATH**/ ?>