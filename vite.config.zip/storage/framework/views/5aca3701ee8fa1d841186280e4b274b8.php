<?php echo $__env->make('finance.accountant.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('title', 'Accountant - Jobcard Status'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-sign-out-alt text-indigo-500 mr-2"></i> Jobcard Status
    </h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-indigo-600 to-purple-600">
                <tr>
                    <?php $__currentLoopData = ['JC #','Customer','Vehicle','Reg','Mobile','MSI','SA','Status','Invoice','Total','Rec','Action']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($h); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 font-mono"><?php echo e($j->Jobc_id); ?></td>
                    <td class="px-4 py-3"><?php echo e($j->Customer_name); ?></td>
                    <td class="px-4 py-3"><?php echo e($j->Variant); ?></td>
                    <td class="px-4 py-3"><?php echo e($j->Registration); ?></td>
                    <td class="px-4 py-3"><?php echo e($j->mobile); ?></td>
                    <td class="px-4 py-3"><?php echo e($j->MSI_cat); ?></td>
                    <td class="px-4 py-3"><?php echo e($j->SA); ?></td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-1 rounded-full text-xs font-medium
                            <?php echo e($j->status=='2' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'); ?>">
                            <?php echo e($j->status=='2' ? 'Ready' : 'Invoiced'); ?>

                        </span>
                    </td>
                    <td class="px-4 py-3 font-mono"><?php echo e($j->Invoice_id ?? '—'); ?></td>
                    <td class="px-4 py-3"><?php echo e($j->Total ? 'Rs '.number_format($j->Total) : '—'); ?></td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-1 rounded-full text-xs
                            <?php echo e($j->Rec_status ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'); ?>">
                            <?php echo e($j->Rec_status ? 'Recovered' : 'Pending'); ?>

                        </span>
                    </td>
                    <td class="px-4 py-3">
                        <?php if($j->Invoice_id): ?>
                        <a href="<?php echo e(route('cashier.print-invoice', ['id'=>$j->Invoice_id])); ?>" target="_blank"
                           class="text-indigo-600 hover:underline text-xs">Print</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="12" class="px-4 py-8 text-center text-gray-400">No jobs found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/finance/accountant/jobcard_status.blade.php ENDPATH**/ ?>