<?php $__env->startSection('title', 'SM - Reports'); ?>
<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('service.partials.sm-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow-sm p-6 mb-4">
    <h2 class="text-2xl font-semibold text-gray-800 mb-4">Reports</h2>
    <form method="GET" action="<?php echo e(route('sm.reports')); ?>" class="flex flex-wrap gap-3 items-end">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">From</label>
            <input type="date" name="from_date" value="<?php echo e($fromDate); ?>" class="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">To</label>
            <input type="date" name="to_date" value="<?php echo e($toDate); ?>" class="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Report</label>
            <select name="tab" class="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="summary"  <?php echo e($tab=='summary'  ? 'selected' : ''); ?>>Summary by SA</option>
                <option value="labor"    <?php echo e($tab=='labor'    ? 'selected' : ''); ?>>Labor Analysis</option>
                <option value="parts"    <?php echo e($tab=='parts'    ? 'selected' : ''); ?>>Parts Usage</option>
                <option value="sa"       <?php echo e($tab=='sa'       ? 'selected' : ''); ?>>SA Performance</option>
            </select>
        </div>
        <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md transition-colors">
            <i class="fa fa-bar-chart mr-2"></i> Generate
        </button>
    </form>
</div>

<?php if($data->isNotEmpty()): ?>
<div class="bg-white rounded-lg shadow-sm p-6">
    <h3 class="font-semibold text-gray-700 mb-4"><?php echo e(ucfirst($tab)); ?> Report — <?php echo e($fromDate); ?> to <?php echo e($toDate); ?></h3>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <?php if($tab=='summary'): ?>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">SA</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total ROs</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Closed ROs</th>
                    <?php elseif($tab=='labor'): ?>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Labor</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Count</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Revenue</th>
                    <?php elseif($tab=='parts'): ?>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Part Description</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Qty</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Value</th>
                    <?php elseif($tab=='sa'): ?>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">SA</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total ROs</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Regular</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Campaign</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Warranty</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    <?php if($tab=='summary'): ?>
                        <td class="px-4 py-3 text-sm font-medium text-gray-800"><?php echo e($row->SA); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($row->total); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($row->closed); ?></td>
                    <?php elseif($tab=='labor'): ?>
                        <td class="px-4 py-3 text-sm font-medium text-gray-800"><?php echo e($row->Labor); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($row->type); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($row->count); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e(number_format($row->total,0)); ?></td>
                    <?php elseif($tab=='parts'): ?>
                        <td class="px-4 py-3 text-sm font-medium text-gray-800"><?php echo e($row->part_description); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($row->total_qty); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e(number_format($row->total_value,0)); ?></td>
                    <?php elseif($tab=='sa'): ?>
                        <td class="px-4 py-3 text-sm font-medium text-gray-800"><?php echo e($row->SA); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($row->total_ros); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($row->regular); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($row->campaign); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($row->warranty); ?></td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php elseif(request()->has('tab')): ?>
<div class="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg">No data found for the selected period.</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/service/sm/reports.blade.php ENDPATH**/ ?>