<?php $__env->startSection('title', 'JobCards - Unclosed'); ?>
<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('service.partials.jobcard-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow-sm p-6">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-semibold text-gray-800">Open Repair Orders</h2>
        <a href="<?php echo e(route('jobcard.add-vehicle')); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md transition-colors">
            <i class="fa fa-plus mr-2"></i> Open New RO
        </a>
    </div>
    <?php if(session('success')): ?><div class="mb-4 p-3 bg-green-100 text-green-800 rounded-md"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if(session('error')): ?><div class="mb-4 p-3 bg-red-100 text-red-800 rounded-md"><?php echo e(session('error')); ?></div><?php endif; ?>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-red-600">
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Jobcard#</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Vehicle</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Registration</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Customer</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Mobile</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Open Date</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $unclosedJobs ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition-colors">
                    <td class="px-4 py-3 text-sm font-bold text-gray-900">#<?php echo e($job->Jobc_id); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($job->Variant); ?></td>
                    <td class="px-4 py-3 text-sm font-medium text-red-600"><?php echo e($job->Registration); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($job->Customer_name); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($job->mobile); ?></td>
                    <td class="px-4 py-3 text-sm text-gray-500"><?php echo e(\Carbon\Carbon::parse($job->Open_date_time)->format('d/m/Y g:i A')); ?></td>
                    <td class="px-4 py-3">
                        <div class="flex flex-wrap gap-1">
                            <a href="<?php echo e(route('jobcard.additional.jobrequest', $job->Jobc_id)); ?>" class="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs rounded transition-colors">JobRequest</a>
                            <a href="<?php echo e(route('jobcard.additional.part', $job->Jobc_id)); ?>" class="px-2 py-1 bg-cyan-600 hover:bg-cyan-700 text-white text-xs rounded transition-colors">Spare Parts</a>
                            <a href="<?php echo e(route('jobcard.additional.sublet', $job->Jobc_id)); ?>" class="px-2 py-1 bg-yellow-500 hover:bg-yellow-600 text-white text-xs rounded transition-colors">Sublet</a>
                            <a href="<?php echo e(route('jobcard.additional.consumable', $job->Jobc_id)); ?>" class="px-2 py-1 bg-orange-500 hover:bg-orange-600 text-white text-xs rounded transition-colors">Consumble</a>
                            <form method="POST" action="<?php echo e(route('jobcard.complete.process')); ?>" class="inline" onsubmit="return confirm('Start working on RO #<?php echo e($job->Jobc_id); ?>?')">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="job_id" value="<?php echo e($job->Jobc_id); ?>">
                                <input type="hidden" name="comp_appointed" value="<?php echo e($job->comp_appointed); ?>">
                                <button type="submit" class="px-2 py-1 bg-red-600 hover:bg-red-700 text-white text-xs rounded transition-colors">Start Working</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-6 py-8 text-center text-gray-400"><i class="fa fa-inbox text-3xl block mb-2"></i>No open jobcards found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\3spro\resources\views/service/jobcard/index.blade.php ENDPATH**/ ?>