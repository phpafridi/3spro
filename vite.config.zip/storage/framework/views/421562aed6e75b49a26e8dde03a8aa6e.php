
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Purchase Invoice #<?php echo e($invoice->Invoice_no); ?></title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px 10px; text-align: left; }
        th { background: #f0f0f0; font-weight: bold; }
        .header { text-align: center; margin-bottom: 20px; }
        .total { text-align: right; font-weight: bold; font-size: 14px; margin-top: 10px; }
        .info-row { display: flex; gap: 20px; margin-bottom: 15px; flex-wrap: wrap; }
        @media print { button { display: none; } }
    </style>
</head>
<body>
<div class="header">
    <h2>Purchase Invoice <?php echo e($tax ? '(With Tax)' : ''); ?></h2>
    <p>Invoice No: <strong>#<?php echo e($invoice->Invoice_no); ?></strong> | Bill No: <?php echo e($invoice->Invoice_number); ?></p>
</div>
<div class="info-row">
    <span>Jobber: <strong><?php echo e($invoice->jobber); ?></strong></span>
    <span>Payment: <strong><?php echo e($invoice->payment_method); ?></strong></span>
    <span>PR: <strong><?php echo e($invoice->Purchase_Requis); ?></strong></span>
    <span>Date: <strong><?php echo e($invoice->mdate ? \Carbon\Carbon::parse($invoice->mdate)->format('d-M-Y') : '-'); ?></strong></span>
    <span>Delivery Note: <?php echo e($invoice->deleverynote); ?></span>
    <span>Receiver: <?php echo e($invoice->Receivername); ?></span>
</div>
<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Part No</th>
            <th>Description</th>
            <th>Category</th>
            <th>Unit</th>
            <th>Qty</th>
            <th>Unit Price</th>
            <th>Net Amount</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $invoice->stockItems ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i+1); ?></td>
            <td><?php echo e($item->part_no); ?></td>
            <td><?php echo e($item->Description); ?></td>
            <td><?php echo e($item->cate_type); ?></td>
            <td><?php echo e($item->unit); ?></td>
            <td><?php echo e($item->quantity); ?></td>
            <td><?php echo e(number_format($item->Price, 2)); ?></td>
            <td><?php echo e(number_format($item->Netamount, 2)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="total">Total Amount: <?php echo e(number_format($invoice->Total_amount ?? 0, 2)); ?></div>
<?php if($tax ?? false): ?>
<div class="total">Tax (17%): <?php echo e(number_format(($invoice->Total_amount ?? 0) * 0.17, 2)); ?></div>
<div class="total">Grand Total: <?php echo e(number_format(($invoice->Total_amount ?? 0) * 1.17, 2)); ?></div>
<?php endif; ?>
<br>
<button onclick="window.print()">Print</button>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\3spro\resources\views/parts/entry/sale/files/print_purch.blade.php ENDPATH**/ ?>