@extends('layouts.master')
@include('finance.accountant.sidebar')
@section('title', 'Finance Reports')
@section('content')
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-key text-indigo-500 mr-2"></i> Finance Reports
    </h2>
    <div class="mb-6">
        <input type="text" id="fin_reservation" class="border border-gray-300 rounded-lg px-3 py-2 text-sm w-72"
            value="{{ date('m/d/Y') }} - {{ date('m/d/Y') }}">
    </div>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
        @foreach(['GSL Report','GL Report','Trial Balance','Income Statement','Balance Sheet','Cash Flow'] as $r)
        <button onclick="alert('{{ $r }}: '+document.getElementById('fin_reservation').value)"
            class="px-4 py-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 text-sm font-medium text-left">
            <i class="fas fa-file-alt mr-2"></i>{{ $r }}
        </button>
        @endforeach
    </div>
    <p class="mt-6 text-xs text-gray-400">These reports are generated from the Accounts module (voucher data). Connect route to your report controllers.</p>
</div>
@push('scripts')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">
<script src="https://cdn.jsdelivr.net/npm/moment/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script>$('#fin_reservation').daterangepicker();</script>
@endpush
@endsection
