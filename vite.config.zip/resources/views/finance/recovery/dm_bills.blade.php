@extends('layouts.master')
@include('finance.recovery.sidebar')
@section('title', 'DM Bills')
@section('content')
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-file-invoice text-indigo-500 mr-2"></i> Pending DM Bills
    </h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-indigo-600 to-purple-600">
                <tr>
                    @foreach(['Invoice','JC #','Customer','Mobile','Total','Closing Date','Action'] as $h)
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ $h }}</th>
                    @endforeach
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse($bills as $b)
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 font-mono font-bold">{{ $b->Invoice_id }}</td>
                    <td class="px-4 py-3 font-mono">{{ $b->Jobc_id }}</td>
                    <td class="px-4 py-3">{{ $b->Customer_name }}</td>
                    <td class="px-4 py-3">{{ $b->mobile }}</td>
                    <td class="px-4 py-3 font-medium text-red-600">Rs {{ number_format($b->Total) }}</td>
                    <td class="px-4 py-3 text-xs text-gray-500">{{ $b->closing_time }}</td>
                    <td class="px-4 py-3">
                        <a href="{{ route('recovery.add-debt', ['id'=>$b->Invoice_id]) }}"
                           class="px-3 py-1 bg-red-100 text-red-700 rounded-lg text-xs hover:bg-red-200">Add Debit</a>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="px-4 py-8 text-center text-gray-400">No pending DM bills.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
