@extends('layouts.master')
@include('finance.recovery.sidebar')
@section('title', 'Recovery Statistics')
@section('content')
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        <i class="fas fa-chart-bar text-indigo-500 mr-2"></i> Monthly Recovery Statistics
    </h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-gradient-to-r from-indigo-600 to-purple-600">
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Year</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Month</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">Total Debit</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse($stats as $s)
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3">{{ $s->year }}</td>
                    <td class="px-4 py-3">{{ DateTime::createFromFormat('!m', $s->month)->format('F') }}</td>
                    <td class="px-4 py-3 font-medium text-red-600">Rs {{ number_format($s->total) }}</td>
                </tr>
                @empty
                <tr><td colspan="3" class="px-4 py-8 text-center text-gray-400">No data.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
