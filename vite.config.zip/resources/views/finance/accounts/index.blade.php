@extends('layouts.master')
@include('finance.accounts.sidebar')
@section('title', 'Finance Reports')
@section('content')
<div class="bg-white rounded-2xl shadow-sm p-6">
    <h2 class="text-2xl font-semibold text-gray-800 mb-2">
        <i class="fas fa-chart-line text-indigo-500 mr-2"></i> Finance Reports
    </h2>
    <p class="text-gray-500 text-sm mb-6">Select a date range and generate financial reports.</p>
    <div class="mb-6">
        <input type="text" id="fin_reservation" class="border border-gray-300 rounded-lg px-3 py-2 text-sm w-72"
            value="{{ date('m/d/Y') }} - {{ date('m/d/Y') }}">
    </div>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
        @foreach([
            ['GSL Report','indigo'], ['GL Report','indigo'], ['Trial Balance','purple'],
            ['Income Statement','green'], ['Balance Sheet','blue'], ['Cash Flow','sky']
        ] as [$label, $color])
        <button class="px-4 py-4 rounded-xl border-2 border-{{ $color }}-200 bg-{{ $color }}-50 hover:bg-{{ $color }}-100 text-{{ $color }}-700 font-medium text-sm text-left transition">
            <i class="fas fa-file-alt mr-2"></i>{{ $label }}
        </button>
        @endforeach
    </div>
</div>
@push('scripts')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">
<script src="https://cdn.jsdelivr.net/npm/moment/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script>$('#fin_reservation').daterangepicker();</script>
@endpush
@endsection
