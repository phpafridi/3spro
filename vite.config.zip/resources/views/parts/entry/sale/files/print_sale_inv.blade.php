<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Parts Sale Invoice</title>
<style>
body { font-family: Arial, sans-serif; font-size: 13px; margin: 10px; }
.tblehds { background:#8E8E8E; color:#fff; font-size:14px; padding:5px 8px; }
.theads   { background:#CCC;   color:#000; font-size:13px; padding:5px 8px; }
.theads_ans { background:#CCC; color:#000; font-size:12px; font-family:'Courier New',monospace; padding:5px 8px; }
table { border-collapse:collapse; }
.pagebreak { page-break-before:always; border:dashed; padding:10px; position:relative; overflow:hidden; }
.pagebreak img.imagebg { position:absolute; left:0; top:0; width:90%; height:100%; opacity:0.25; }
@media print { .no-print { display:none; } }
</style>
</head>
<body onload="window.print();">

<div align="center">
    <img src="{{ asset('images/header1.png') }}" width="800px" onerror="this.style.display='none'">
    <br>
    <h2 style="font-family:'Courier New',Courier,monospace;text-decoration:underline;margin:0;">
        Parts Sale Invoice
        <small>({{ request()->has('copy') ? 'Copy' : 'Original' }})</small>
    </h2>
</div>
<br><br>

<table border="0" width="800px" cellpadding="0">
    <tr>
        <td colspan="5"></td>
        <td class="theads" colspan="2">Sale Date :</td>
        <td class="theads_ans" colspan="2">{{ \Carbon\Carbon::parse($invoice->datetime)->format('d M y') }}</td>
    </tr>
    <tr>
        <td class="theads" colspan="2">Jobber :</td>
        <td class="theads_ans">{{ $invoice->Jobber }}</td>
        <td></td><td></td>
        <td class="theads" colspan="2">Invoice Number :</td>
        <td class="theads_ans" colspan="2">GDN-{{ $invoice->sale_inv }}</td>
    </tr>
    <tr>
        <td class="theads" colspan="2">Payment Methods :</td>
        <td class="theads_ans">{{ $invoice->payment_method }}</td>
    </tr>
    <tr><td colspan="9"><br></td></tr>

    {{-- Parts header --}}
    <tr bgcolor="black">
        <td class="tblehds">S.no</td>
        <td class="tblehds">Part No</td>
        <td class="tblehds" colspan="2">Description</td>
        <td class="tblehds">Qty</td>
        <td class="tblehds">Unit Price</td>
        <td class="tblehds">Discount</td>
        <td class="tblehds">Tax</td>
        <td class="tblehds">Total</td>
    </tr>

    @php $serial = 0; @endphp
    @foreach($parts as $p)
    @php $serial++; @endphp
    <tr>
        <td>{{ $serial }}</td>
        <td>{{ $p->part_no }}</td>
        <td colspan="2" style="font-size:10px;">{{ $p->Description }}</td>
        <td align="center">{{ $p->quantity }}</td>
        <td align="center">{{ $p->sale_price }}</td>
        <td align="center">{{ $p->discount ?? 0 }}</td>
        <td align="center">{{ $p->tax ?? 0 }}</td>
        <td>{{ $p->netamount + ($p->tax ?? 0) }}</td>
    </tr>
    @endforeach

    <tr><td colspan="9"><br></td></tr>

    {{-- Totals --}}
    <tr>
        <td colspan="5"></td>
        <td colspan="2" class="tblehds" align="right">Gross Sale:</td>
        <td class="tblehds" colspan="2" align="center">{{ $invoice->Total_amount + $invoice->discount }}</td>
    </tr>
    <tr>
        <td colspan="5"></td>
        <td colspan="2" class="theads" align="right">Discount:</td>
        <td class="theads" colspan="2" align="center">{{ $invoice->discount }}</td>
    </tr>
    <tr>
        <td colspan="5"></td>
        <td colspan="2" class="theads" align="right">GST 17%:</td>
        <td class="theads" colspan="2" align="center">{{ $invoice->tax }}</td>
    </tr>
    <tr>
        <td colspan="5"></td>
        <td colspan="2" class="tblehds" align="right">Net Amount :</td>
        <td class="tblehds" colspan="2" align="center">Rs {{ number_format($invoice->Total_amount + $invoice->tax) }}</td>
    </tr>
</table>

<div><p style="font-size:12px;">Remarks:<br>{{ $invoice->remarks }}</p></div>

<br><br><br>
<table width="800px">
    <tr>
        <td>________________________________<br>Sold By: {{ $invoice->user }}</td>
        <td>________________________________<br>Jobber: {{ $invoice->Jobber }}</td>
        <td>________________________________<br>Warehouse Incharge</td>
    </tr>
</table>

{{-- GATE PASS --}}
<div class="pagebreak">
    <img src="{{ asset('images/parts.png') }}" class="imagebg" onerror="this.style.display='none'">
    <h1 style="font-family:'Courier New',Courier,monospace;text-decoration:underline;margin:0;" align="center">GATE PASS</h1>

    <table border="0" width="700px" cellpadding="0">
        <tr>
            <td colspan="5"></td>
            <td class="theads" colspan="2">Sale Date :</td>
            <td class="theads_ans" colspan="2">{{ \Carbon\Carbon::parse($invoice->datetime)->format('d M y') }}</td>
        </tr>
        <tr>
            <td class="theads" colspan="2">Jobber :</td>
            <td class="theads_ans">{{ $invoice->Jobber }}</td>
            <td></td><td></td>
            <td class="theads" colspan="2">Invoice Number :</td>
            <td class="theads_ans" colspan="2">SJV-{{ $invoice->sale_inv }}</td>
        </tr>
        <tr>
            <td class="theads" colspan="2">Payment Methods :</td>
            <td class="theads_ans">{{ $invoice->payment_method }}</td>
        </tr>
    </table>

    <table width="700px">
        <tr bgcolor="black">
            <td class="tblehds">S.no</td>
            <td class="tblehds" colspan="2">Description</td>
            <td class="tblehds">Qty</td>
        </tr>
        @php $serial = 0; @endphp
        @foreach($parts as $p)
        @php $serial++; @endphp
        <tr>
            <td>{{ $serial }}</td>
            <td colspan="2">{{ $p->Description }}</td>
            <td>{{ $p->quantity }}</td>
        </tr>
        @endforeach
    </table>

    <table width="100%">
        <tr>
            <td align="center"><br>Parts Manager</td>
            <td align="center"><br></td>
            <td align="center"><br>Issued By ({{ $invoice->user }})</td>
        </tr>
        <tr>
            <td align="center"><br><br>_____________________</td>
            <td align="center"><br><br></td>
            <td align="center"><br><br>_____________________</td>
        </tr>
    </table>
</div>

</body>
</html>
