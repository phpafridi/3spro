@extends('parts.layout')
@section('title', 'Parts Sale')
@section('content')

<style>
body { background:#fce8dc; }
.tble { border-collapse:collapse; }
.tble_td { padding:6px 12px; font-size:13px; color:#333; }
.thd { background:linear-gradient(135deg,#c0392b,#7a1a1a); color:#fff; }
.form_inp { border:1px solid #ccc; border-radius:4px; padding:5px 8px; font-size:13px; }
.imp_span { color:#dc2626; font-weight:700; }
.body1 { font-family:Arial,sans-serif; }
.tble-outer {
    background:linear-gradient(135deg,#f8d7d7,#fce4e4,#f5c6c6);
    border:1px solid #e2a8a8; border-radius:12px; padding:20px; max-width:500px;
}
.tble-outer h1 {
    text-align:center; font-size:22px; font-weight:900; color:#3d0000;
    font-family:'Georgia',serif; margin-bottom:12px;
    background:linear-gradient(135deg,#c0392b,#7a1a1a);
    -webkit-background-clip:text; -webkit-text-fill-color:transparent;
    background-clip:text;
}
input.form_inp, select.form_inp {
    border:1px solid #d1d5db; border-radius:20px; padding:5px 10px;
    font-size:13px; background:#fff0f0; width:100%;
}
input.form_inp:focus, select.form_inp:focus { outline:none; border-color:#dc2626; }
.btn {
    background:linear-gradient(135deg,#5a1a1a,#3d0000);
    color:#fff; padding:8px 28px; font-size:13px; font-weight:700;
    border-radius:20px; border:none; cursor:pointer;
}
.btn-check {
    background:linear-gradient(135deg,#1e3a5f,#0f2440);
    color:#fff; padding:7px 22px; font-size:13px; font-weight:700;
    border-radius:20px; border:none; cursor:pointer; text-decoration:none; display:inline-block;
}

/* Purchase History table on right side */
#stock_available { background:#fce8dc; padding:8px; border-radius:8px; }
#stock_available table { border-collapse:collapse; }
#stock_available th { background:#3498db; color:#fff; padding:4px 7px; font-size:12px; border-radius:3px; }
#stock_available td { padding:4px 7px; font-size:12px; border-bottom:1px solid #e5e7eb; }
.trrr:hover td { background:rgba(100,150,255,0.35); color:#fff; cursor:pointer; }
#description { color:#dc2626; font-size:12px; font-weight:700; margin-top:3px; }
#lbl { font-weight:700; color:#dc2626; font-size:15px; min-height:18px; }

/* Typeahead dropdown */
.tt-dropdown-menu {
    background:#fff; border:1px solid #ccc; border-radius:6px;
    box-shadow:0 4px 12px rgba(0,0,0,0.15); width:220px; z-index:9999;
}
.tt-suggestion { padding:6px 12px; font-size:13px; cursor:pointer; }
.tt-suggestion:hover, .tt-suggestion.tt-is-under-cursor { background:#3498db; color:#fff; }
</style>

@if(session('error'))
<div style="background:#fee2e2;border-left:4px solid #ef4444;padding:10px;margin-bottom:10px;border-radius:4px;font-size:13px;">
    {{ session('error') }}
</div>
@endif

<table width="100%" border="0"><tr>
<td width="55%" valign="top">
<div class="tble-outer">
    <h1>Parts Sell</h1>

    <form action="{{ isset($sale_inv) ? route('parts.sale.add.part', $sale_inv) : route('parts.sale.store') }}"
          method="POST" name="saleForm" onsubmit="return validateSaleForm()">
        @csrf
        <table class="tble" align="center" border="0">

            {{-- ── First visit: Jobber + Payment method ── --}}
            @if(!isset($sale_inv))
            <tr>
                <td class="tble_td">Jobber <span class="imp_span">*</span>:</td>
                <td class="tble_td">
                    <select name="required_jobber" class="form_inp" id="jobber"
                            onchange="jobberCheck()" required>
                        <option value=""></option>
                        <option>Counter Sale</option>
                        @foreach($jobbers as $j)
                        <option>{{ $j->jbr_name }}</option>
                        @endforeach
                    </select>
                </td>
            </tr>
            <tr>
                <td class="tble_td">Transaction:</td>
                <td class="tble_td">
                    <select class="form_inp" name="payment_method" id="payment_method" required>
                        <option>Cash</option>
                    </select>
                </td>
            </tr>

            {{-- ── Invoice exists: show ID ── --}}
            @else
            <tr>
                <td class="tble_td" colspan="2">
                    Invoice ID — <span class="imp_span" style="font-size:16px;">{{ $sale_inv }}</span>
                    @if(isset($invoice))
                        &nbsp;|&nbsp; {{ $invoice->Jobber }} &nbsp;|&nbsp; {{ $invoice->payment_method }}
                    @endif
                </td>
            </tr>
            @endif

            {{-- Part Number typeahead --}}
            <tr>
                <td class="tble_td">Part Number <span class="imp_span">*</span>:</td>
                <td class="tble_td">
                    <input type="text" name="typeahead" id="partno"
                           class="typeahead tt-query form_inp"
                           autocomplete="off" spellcheck="false"
                           placeholder="Type Part number" required>
                    <input type="hidden" name="descript" id="descript">
                    <div id="description"></div>
                </td>
            </tr>

            {{-- Stock ID (filled by clicking row in table) --}}
            <tr>
                <td class="tble_td">Stock ID <span class="imp_span">*</span>:</td>
                <td class="tble_td">
                    <div id="lbl"></div>
                    <input type="hidden" name="required_stock_id" id="stk">
                    <input type="hidden" name="remaining_qtyy"    id="remaining_qtyy">
                </td>
            </tr>

            {{-- Quantity --}}
            <tr>
                <td class="tble_td">Quantity <span class="imp_span">*</span>:</td>
                <td class="tble_td">
                    <input type="number" class="form_inp" name="required_qty" id="qty"
                           autocomplete="off" oninput="calculate()" required min="1">
                </td>
            </tr>

            {{-- Sale Price --}}
            <tr>
                <td class="tble_td">Sale Price <span class="imp_span">*</span>:</td>
                <td class="tble_td">
                    <input placeholder="Rs" type="number" autocomplete="off"
                           name="required_uprice" class="form_inp" id="unit_price"
                           oninput="calculate()" required min="0" step="0.01">
                </td>
            </tr>

            {{-- Discount --}}
            <tr>
                <td class="tble_td">Discount <span class="imp_span">*</span>:</td>
                <td class="tble_td" style="display:flex;gap:4px;align-items:center;">
                    <input type="number" style="width:5em;" value="0" step="any"
                           class="form_inp" name="dis_per" id="dis_per"
                           oninput="disPerF()" max="100">
                    %
                    <input style="width:7em;" type="number" value="0"
                           name="discount" class="form_inp" id="discount"
                           oninput="disAmtF()" required>
                </td>
            </tr>

            {{-- Tax --}}
            <tr>
                <td class="tble_td">Tax <span class="imp_span">*</span>:</td>
                <td class="tble_td" style="display:flex;gap:4px;align-items:center;">
                    <input type="number" style="width:5em;" value="0" step="any"
                           class="form_inp" name="tax_per" id="tax_per"
                           oninput="taxPerF()" max="100">
                    %
                    <input style="width:7em;" type="number" value="0"
                           name="tax" class="form_inp" id="tax"
                           oninput="taxAmtF()" required>
                </td>
            </tr>

            {{-- Net Amount --}}
            <tr>
                <td class="tble_td">Net Amount</td>
                <td class="tble_td">
                    <input type="hidden" name="required_netprice" id="net_amount">
                    <div id="netprice"></div>
                </td>
            </tr>

            {{-- Submit --}}
            <tr>
                <td align="center" colspan="2" style="padding-top:10px;">
                    <input type="submit" value="Submit &amp; Add more" name="submit3" class="btn">
                </td>
            </tr>
        </table>
    </form>
</div>

{{-- Check Invoice & Print — only after invoice exists --}}
@if(isset($sale_inv) && $sale_inv)
<div style="text-align:center;margin-top:16px;">
    <a href="{{ route('parts.sale.invoice', $sale_inv) }}" class="btn-check">
        Check Invoice &amp; Print
    </a>
</div>
@endif

</td>
<td width="45%" valign="top">
    <div id="stock_available"></div>
</td>
</tr></table>

{{-- ── Scripts ── --}}
<script>
/* Jobber → payment method */
function jobberCheck() {
    var jobber = document.getElementById('jobber').value;
    var sel    = document.getElementById('payment_method');
    sel.options.length = 0;
    sel.options[0] = jobber === 'Counter Sale' ? new Option('Cash') : new Option('Credit');
}

/* Typeahead — vanilla JS matching original typeahead behaviour */
/* Typeahead — vanilla JS matching original typeahead behaviour */
var partInput = document.getElementById('partno');
var ttMenu    = document.createElement('div');
ttMenu.className = 'tt-dropdown-menu';
ttMenu.style.display = 'none';
ttMenu.style.position = 'absolute';
ttMenu.style.zIndex   = '9999';
partInput.parentNode.style.position = 'relative';
partInput.parentNode.appendChild(ttMenu);

var ttTimer;
partInput.addEventListener('input', function() {
    clearTimeout(ttTimer);
    var val = this.value.trim();
    if (val.length < 2) { ttMenu.style.display='none'; return; }
    ttTimer = setTimeout(function() {
        fetch('{{ route("parts.ajax.search-part") }}?key=' + encodeURIComponent(val))
            .then(function(r){ return r.json(); })
            .then(function(data) {
                ttMenu.innerHTML = '';
                if (!data.length) { ttMenu.style.display='none'; return; }
                data.forEach(function(item) {
                    var suggestion = document.createElement('div');
                    suggestion.className = 'tt-suggestion';
                    // Display both part number and description in dropdown
                    suggestion.textContent = item.value + (item.desc ? ' — ' + item.desc : '');
                    suggestion.addEventListener('mousedown', function(e) {
                        e.preventDefault();
                        partInput.value = item.value;
                        // Set description fields
                        document.getElementById('descript').value = item.desc || '';
                        document.getElementById('description').textContent = item.desc || '';
                        // Set category if available
                        if (item.category) {
                            // Note: You might need to add a category dropdown field
                            // For now, just log it
                            console.log('Category:', item.category);
                        }
                        ttMenu.style.display = 'none';
                        onPartSelected(item.value);  // Pass the part number for stock search
                    });
                    ttMenu.appendChild(suggestion);
                });
                ttMenu.style.display = 'block';
            }).catch(function(error){ 
                console.error('Error fetching parts:', error);
            });
    }, 300);
});

document.addEventListener('click', function(e) {
    if (!partInput.contains(e.target)) ttMenu.style.display = 'none';
});

/* Called when a part is selected from dropdown — matches original typeahead:selected */
function onPartSelected(partNo) {
    /* 1. Load description */
    fetch('{{ route("parts.ajax.search-part-desc") }}?partn=' + encodeURIComponent(partNo))
        .then(function(r){ return r.json(); })
        .then(function(d) {
            document.getElementById('description').textContent = d.desc || '';
            document.getElementById('descript').value          = d.desc || '';
        }).catch(function(){});

    /* 2. Load stock table — exact part_no match */
    fetch('{{ route("parts.ajax.search-stock") }}?key=' + encodeURIComponent(partNo))
        .then(function(r){ return r.json(); })
        .then(function(d) { renderStockTable(d, partNo); })
        .catch(function(){});
}

/* Render the Purchase History table exactly like original search_stock.php output */
/* Render the Purchase History table exactly like original search_stock.php output */
function renderStockTable(data, partNo) {
    var html = '<div style="position:relative;">' +
        '<div style="height:550px;overflow:auto;margin-top:8px;">' +
        '<table align="center" class="tble">' +
        '<tr><th colspan="10" align="center" style="background:#3498db;color:#fff;padding:6px;">Purchase History</th></tr>' +
        '<tr>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">Stock ID</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">GRN</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">Inv</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">P-Date</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">Jobber</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">P-Qty</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">R-Qty</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">U-Price</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">Model</th>' +
        '<th style="color:#fff;background:#3498db;border-radius:3px;padding:4px 7px;">Location</th>' +
        '</tr>';

    if (!data || !data.length) {
        html += '<tr><td colspan="10" align="center" style="padding:10px;color:#666;">Required Part# is not available in Stock</td></tr>';
    } else {
        data.forEach(function(s) {
            var clickable = s.remain_qty > 0;
            var rowStyle  = s.remain_qty == 0 ? ' bgcolor="#ffcccc"' : '';
            var tdClick   = clickable
                ? ' onclick="getstock_id(' + s.stock_id + ',' + s.remain_qty + ');" style="cursor:pointer;"'
                : ' style="cursor:not-allowed;"';

            html += '<tr class="trrr" align="center"' + rowStyle + '>';
            html += '<td align="left"' + tdClick + '>↖ ' + s.stock_id + '</td>';
            html += '<td>' + (s.grn        || '') + '</td>';
            html += '<td>' + (s.inv_number || '') + '</td>';
            html += '<td>' + (s.purch_date || '') + '</td>';
            html += '<td style="font-size:11px;">' + (s.jobber || '') + '</td>';
            html += '<td>' + (s.quantity   || '') + '</td>';
            html += '<td id="remain_qty">' + s.remain_qty + '</td>';
            html += '<td align="left">Rs:' + s.price + '</td>';
            html += '<td align="left">' + (s.model    || '') + '</td>';
            html += '<td align="left">' + (s.location || '') + '</td>';
            html += '</tr>';
        });
    }

    html += '<tr><td colspan="10" align="center" style="padding:6px;">' +
            '<a target="_blank" href="' + '{{ route("parts.reports.sale-history") }}?part=' + partNo + '" style="color:#3498db;font-size:12px;">Sale History</a>' +
            '</td></tr>';
    html += '</table></div></div>';
    document.getElementById('stock_available').innerHTML = html;
}
/* Called when clicking a stock row — fills Stock ID field */
function getstock_id(val, rem_qty) {
    document.getElementById('stk').value            = val;
    document.getElementById('remaining_qtyy').value = rem_qty;
    document.getElementById('lbl').innerHTML        = val;
}

/* ── Calculation ── (exact match of original) */
function calculate() {
    var price    = parseFloat(document.getElementById('unit_price').value) || 0;
    var discount = parseFloat(document.getElementById('discount').value)   || 0;
    var tax      = parseFloat(document.getElementById('tax').value)        || 0;
    var qty      = parseFloat(document.getElementById('qty').value)        || 0;
    var result   = ((price * qty) - discount) + tax;
    document.getElementById('net_amount').value   = result;
    document.getElementById('netprice').innerHTML = result;
}
function taxAmtF() {
    var u = parseFloat(document.getElementById('unit_price').value)||0;
    var t = parseFloat(document.getElementById('tax').value)||0;
    var q = parseFloat(document.getElementById('qty').value)||0;
    document.getElementById('tax_per').value = (u && q) ? ((t/u)*q)*100 : 0;
    calculate();
}
function taxPerF() {
    var u  = parseFloat(document.getElementById('unit_price').value)||0;
    var tp = parseFloat(document.getElementById('tax_per').value)||0;
    var q  = parseFloat(document.getElementById('qty').value)||0;
    document.getElementById('tax').value = (tp/100)*(u*q);
    calculate();
}
function disAmtF() {
    var u = parseFloat(document.getElementById('unit_price').value)||0;
    var d = parseFloat(document.getElementById('discount').value)||0;
    var q = parseFloat(document.getElementById('qty').value)||0;
    document.getElementById('dis_per').value = (u && q) ? ((d/u)*q)*100 : 0;
    calculate();
}
function disPerF() {
    var u  = parseFloat(document.getElementById('unit_price').value)||0;
    var dp = parseFloat(document.getElementById('dis_per').value)||0;
    var q  = parseFloat(document.getElementById('qty').value)||0;
    document.getElementById('discount').value = (dp/100)*(u*q);
    calculate();
}
function validateSaleForm() {
    var stk  = document.getElementById('stk').value;
    var req  = parseFloat(document.getElementById('qty').value)||0;
    var avbl = parseFloat(document.getElementById('remaining_qtyy').value)||0;
    if (!stk || (req > avbl)) {
        alert('Stock ID not selected OR Available stock is less than required!!!');
        return false;
    }
    return true;
}
</script>
@endsection
