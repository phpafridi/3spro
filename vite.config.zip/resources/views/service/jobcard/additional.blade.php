@extends('layouts.master')

@section('title', 'Jobcard - RO# ' . $jobId)

@section('content')
<div class="right_col" role="main">
    <div class="page-title">
        <div class="title_left">
            <h3>Jobcard &mdash; RO# {{ $jobId }}</h3>
        </div>
        <div class="title_right">
            <a href="{{ route('jobcard.index') }}" class="btn btn-default pull-right">
                <i class="fa fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>
    <div class="clearfix"></div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    {{-- RO SUMMARY --}}
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Vehicle &amp; Customer Info</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-md-3"><strong>Registration:</strong> {{ $jobcard->Registration }}</div>
                        <div class="col-md-3"><strong>Variant:</strong> {{ $jobcard->Variant }}</div>
                        <div class="col-md-3"><strong>Customer:</strong> {{ $jobcard->Customer_name }}</div>
                        <div class="col-md-3"><strong>Mobile:</strong> {{ $jobcard->mobile }}</div>
                    </div>
                    <div class="row" style="margin-top:8px;">
                        <div class="col-md-3"><strong>SA:</strong> {{ $jobcard->SA }}</div>
                        <div class="col-md-3"><strong>RO Type:</strong> {{ $jobcard->RO_type }}</div>
                        <div class="col-md-3"><strong>Open Date:</strong> {{ $jobcard->Open_date_time }}</div>
                        <div class="col-md-3"><strong>Mileage:</strong> {{ $jobcard->Mileage }}</div>
                    </div>
                    <div class="row" style="margin-top:8px;">
                        <div class="col-md-3">
                            <a href="{{ route('jobcard.customer.edit', $jobcard->Customer_id) }}?vehicle_id={{ $jobcard->Vehicle_id }}"
                               class="btn btn-xs btn-warning">
                                <i class="fa fa-edit"></i> Edit Customer
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ADD BUTTONS --}}
    <div class="row" style="margin-bottom:10px;">
        <div class="col-md-12">
            <a href="{{ route('jobcard.additional.jobrequest', $jobId) }}" class="btn btn-primary">
                <i class="fa fa-plus"></i> Add Labor
            </a>
            <a href="{{ route('jobcard.additional.part', $jobId) }}" class="btn btn-info">
                <i class="fa fa-cogs"></i> Add Part
            </a>
            <a href="{{ route('jobcard.additional.consumable', $jobId) }}" class="btn btn-warning">
                <i class="fa fa-tint"></i> Add Consumable
            </a>
            <a href="{{ route('jobcard.additional.sublet', $jobId) }}" class="btn btn-default">
                <i class="fa fa-external-link"></i> Add Sublet
            </a>
        </div>
    </div>

    {{-- LABOR TABLE --}}
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Labor / Job Requests <span class="badge">{{ $labors->count() }}</span></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table class="table table-condensed table-bordered">
                        <thead>
                            <tr>
                                <th>#</th><th>Labor</th><th>Type</th><th>Cost</th>
                                <th>Status</th><th>Team</th><th>Bay</th>
                                <th>Entry</th><th>Additional</th><th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($labors as $l)
                            <tr>
                                <td>{{ $l->Labor_id }}</td>
                                <td>{{ $l->Labor }}</td>
                                <td>{{ $l->type }}</td>
                                <td>{{ number_format($l->cost, 0) }}</td>
                                <td>
                                    @if(!$l->status)
                                        <span class="label label-default">Pending</span>
                                    @elseif($l->status == 'Job Assign')
                                        <span class="label label-info">Assigned</span>
                                    @elseif($l->status == 'Jobclose')
                                        <span class="label label-success">Done</span>
                                    @else
                                        <span class="label label-warning">{{ $l->status }}</span>
                                    @endif
                                </td>
                                <td>{{ $l->team }}</td>
                                <td>{{ $l->bay }}</td>
                                <td>{{ $l->entry_time }}</td>
                                <td>{{ $l->Additional ? 'Yes' : 'No' }}</td>
                                <td>
                                    @if(!$l->status)
                                    <button class="btn btn-xs btn-danger delete-btn"
                                            data-id="{{ $l->Labor_id }}" data-type="id"
                                            title="Delete">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    @endif
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="10" class="text-center text-muted">No labor added.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- PARTS TABLE --}}
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Parts <span class="badge">{{ $parts->count() }}</span></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table class="table table-condensed table-bordered">
                        <thead>
                            <tr>
                                <th>#</th><th>Description</th><th>Qty</th>
                                <th>Unit Price</th><th>Total</th><th>Status</th>
                                <th>Additional</th><th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($parts as $p)
                            <tr>
                                <td>{{ $p->parts_sale_id }}</td>
                                <td>{{ $p->part_description }}</td>
                                <td>{{ $p->qty }}</td>
                                <td>{{ number_format($p->unitprice, 2) }}</td>
                                <td>{{ number_format($p->total, 2) }}</td>
                                <td>{{ $p->status == '0' ? 'Pending' : 'Issued' }}</td>
                                <td>{{ $p->Additional ? 'Yes' : 'No' }}</td>
                                <td>
                                    @if($p->status == '0')
                                    <button class="btn btn-xs btn-danger delete-btn"
                                            data-id="{{ $p->parts_sale_id }}" data-type="Pid">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    @endif
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="8" class="text-center text-muted">No parts added.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- CONSUMABLES TABLE --}}
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Consumables <span class="badge">{{ $consumbles->count() }}</span></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table class="table table-condensed table-bordered">
                        <thead>
                            <tr>
                                <th>#</th><th>Description</th><th>Qty</th>
                                <th>Unit Price</th><th>Total</th><th>Status</th>
                                <th>Additional</th><th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($consumbles as $c)
                            <tr>
                                <td>{{ $c->cons_sale_id }}</td>
                                <td>{{ $c->cons_description }}</td>
                                <td>{{ $c->qty }}</td>
                                <td>{{ number_format($c->unitprice, 2) }}</td>
                                <td>{{ number_format($c->total, 2) }}</td>
                                <td>{{ $c->status == '0' ? 'Pending' : 'Issued' }}</td>
                                <td>{{ $c->Additional ? 'Yes' : 'No' }}</td>
                                <td>
                                    @if($c->status == '0')
                                    <button class="btn btn-xs btn-danger delete-btn"
                                            data-id="{{ $c->cons_sale_id }}" data-type="cnid">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    @endif
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="8" class="text-center text-muted">No consumables added.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- SUBLETS TABLE --}}
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Sublets <span class="badge">{{ $sublets->count() }}</span></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table class="table table-condensed table-bordered">
                        <thead>
                            <tr>
                                <th>#</th><th>Sublet</th><th>Type</th><th>Qty</th>
                                <th>Unit Price</th><th>Total</th><th>Status</th>
                                <th>Additional</th><th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($sublets as $s)
                            <tr>
                                <td>{{ $s->sublet_id }}</td>
                                <td>{{ $s->Sublet }}</td>
                                <td>{{ $s->type }}</td>
                                <td>{{ $s->qty }}</td>
                                <td>{{ number_format($s->unitprice, 2) }}</td>
                                <td>{{ number_format($s->total, 2) }}</td>
                                <td>{{ $s->status ?: 'Pending' }}</td>
                                <td>{{ $s->additional ? 'Yes' : 'No' }}</td>
                                <td>
                                    @if(!$s->status)
                                    <button class="btn btn-xs btn-danger delete-btn"
                                            data-id="{{ $s->sublet_id }}" data-type="sid">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    @endif
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="9" class="text-center text-muted">No sublets added.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>{{-- /right_col --}}

@push('scripts')
<script>
$(document).ready(function() {
    // Delete item via AJAX
    $('.delete-btn').on('click', function() {
        if (!confirm('Are you sure you want to delete this item?')) return;
        var type  = $(this).data('type');
        var id    = $(this).data('id');
        var row   = $(this).closest('tr');
        var data  = { _token: '{{ csrf_token() }}' };
        data[type] = id;

        $.post('{{ route("jobcard.delete-item") }}', data, function(res) {
            if (res.status === 'ok') {
                row.fadeOut(300, function() { $(this).remove(); });
            }
        }).fail(function() {
            alert('Error deleting item. Please try again.');
        });
    });
});
</script>
@endpush
@endsection
