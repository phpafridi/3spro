@extends('layouts.master')

@section('title', 'Add Vehicle / Search Customer')

@section('content')
<div class="right_col" role="main">
    <div class="page-title">
        <div class="title_left">
            <h3>Workshop &mdash; Search / Add Vehicle</h3>
        </div>
    </div>
    <div class="clearfix"></div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    {{-- SEARCH FORM --}}
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title"><h2>Search Existing Vehicle</h2><div class="clearfix"></div></div>
                <div class="x_content">
                    <form method="POST" action="{{ route('jobcard.add-vehicle.search') }}">
                        @csrf
                        <div class="row">
                            <div class="col-md-3">
                                <select name="column" class="form-control">
                                    <option value="Registration" {{ ($column??'')=='Registration'?'selected':'' }}>Registration</option>
                                    <option value="Frame_no"     {{ ($column??'')=='Frame_no'?'selected':'' }}>Frame No</option>
                                    <option value="Engine_no"    {{ ($column??'')=='Engine_no'?'selected':'' }}>Engine No</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <input type="text" name="value" class="form-control"
                                       value="{{ $value ?? '' }}" placeholder="Search value..." required>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fa fa-search"></i> Search
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{-- SEARCH RESULTS --}}
    @isset($vehicles)
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Search Results <small>{{ $vehicles->count() }} found</small></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    @if($vehicles->isEmpty())
                        <div class="alert alert-warning">No vehicles found. You can add a new customer below.</div>
                    @else
                    <table class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th>Registration</th>
                                <th>Frame No</th>
                                <th>Variant</th>
                                <th>Customer</th>
                                <th>Mobile</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($vehicles as $v)
                            <tr>
                                <td>{{ $v->Registration }}</td>
                                <td>{{ $v->Frame_no }}</td>
                                <td>{{ $v->Variant }}</td>
                                <td>{{ $v->Customer_name }}</td>
                                <td>{{ $v->mobile }}</td>
                                <td>
                                    <a href="{{ route('jobcard.additional', ['jobId' => 'new']) }}?vehicle_id={{ $v->Vehicle_id }}"
                                       class="btn btn-xs btn-success">
                                        <i class="fa fa-plus"></i> Open Jobcard
                                    </a>
                                    <a href="{{ route('jobcard.customer.edit', $v->Customer_id) }}?vehicle_id={{ $v->Vehicle_id }}"
                                       class="btn btn-xs btn-warning">
                                        <i class="fa fa-edit"></i> Edit Customer
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
    @endisset

    {{-- ADD NEW CUSTOMER --}}
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Add New Customer &amp; Vehicle</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    {{-- TAB NAVIGATION --}}
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active">
                            <a href="#tab-customer" role="tab" data-toggle="tab">Step 1: Customer</a>
                        </li>
                        <li role="presentation">
                            <a href="#tab-vehicle" role="tab" data-toggle="tab">Step 2: Vehicle</a>
                        </li>
                    </ul>

                    <div class="tab-content" style="padding-top:15px;">
                        {{-- CUSTOMER FORM --}}
                        <div role="tabpanel" class="tab-pane active" id="tab-customer">
                            <form method="POST" action="{{ route('jobcard.add-vehicle.customer') }}" class="form-horizontal">
                                @csrf
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Customer Type</label>
                                    <div class="col-md-4">
                                        <select name="cust_type" class="form-control">
                                            <option>Individuals</option>
                                            <option>Govt</option>
                                            <option>Force</option>
                                            <option>Corporate</option>
                                            <option>Banks</option>
                                            <option>Investor</option>
                                            <option>Others</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Contact Type</label>
                                    <div class="col-md-4">
                                        <select name="contact_type" class="form-control">
                                            <option>Own</option>
                                            <option>Family</option>
                                            <option>Fleet</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Full Name <span class="required">*</span></label>
                                    <div class="col-md-4">
                                        <input type="text" name="name" class="form-control" required
                                               style="text-transform:uppercase" placeholder="Customer name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Primary Mobile <span class="required">*</span></label>
                                    <div class="col-md-4">
                                        <input type="text" name="mobile" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Secondary Phone</label>
                                    <div class="col-md-4">
                                        <input type="text" name="off_phone" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Address</label>
                                    <div class="col-md-4">
                                        <input type="text" name="address" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">CNIC</label>
                                    <div class="col-md-4">
                                        <input type="text" name="cnic" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-offset-3 col-md-4">
                                        <button type="submit" class="btn btn-success">
                                            <i class="fa fa-save"></i> Save Customer &amp; Continue
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        {{-- VEHICLE FORM --}}
                        <div role="tabpanel" class="tab-pane" id="tab-vehicle">
                            <form method="POST" action="{{ route('jobcard.add-vehicle.vehicle.store') }}" class="form-horizontal">
                                @csrf
                                <input type="hidden" name="customer_id" value="{{ request('customer_id') }}">
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Registration <span class="required">*</span></label>
                                    <div class="col-md-4">
                                        <input type="text" name="registration" class="form-control"
                                               required style="text-transform:uppercase">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Model</label>
                                    <div class="col-md-4">
                                        <input type="text" name="model" id="model_input" class="form-control"
                                               placeholder="Start typing model..." autocomplete="off">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Variant <span class="required">*</span></label>
                                    <div class="col-md-4">
                                        <input type="text" name="varaint" id="variant_input" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Make</label>
                                    <div class="col-md-4">
                                        <input type="text" name="make" id="make_input" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Frame No</label>
                                    <div class="col-md-4">
                                        <input type="text" name="fram" class="form-control" style="text-transform:uppercase">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Engine No</label>
                                    <div class="col-md-4">
                                        <input type="text" name="engine" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Colour</label>
                                    <div class="col-md-4">
                                        <input type="text" name="color" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-offset-3 col-md-4">
                                        <button type="submit" class="btn btn-success">
                                            <i class="fa fa-save"></i> Save Vehicle
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>{{-- end tab-content --}}
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
// Autocomplete for model field using variant_codes
$('#model_input').on('keyup', function() {
    var term = $(this).val();
    if (term.length < 2) return;
    $.get('{{ route("jobcard.ajax.variant") }}', {
        name_startsWith: term, row_num: 0
    }, function(data) {
        var models = $.map(data, function(item) {
            var parts = item.split('|');
            return { label: parts[0] + ' - ' + parts[1], value: parts[0],
                     variant: parts[1], make: parts[2], engine: parts[3] };
        });
        $('#model_input').autocomplete({
            source: models,
            select: function(e, ui) {
                $('#variant_input').val(ui.item.variant);
                $('#make_input').val(ui.item.make);
            }
        });
    });
});
</script>
@endpush
@endsection
