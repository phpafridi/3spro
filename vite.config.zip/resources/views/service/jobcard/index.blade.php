@extends('layouts.master')

@section('title', 'Jobcard - Unclosed Jobs')

@section('content')
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Workshop &mdash; Unclosed Job Cards</h3>
            </div>
            <div class="title_right">
                <a href="{{ route('jobcard.add-vehicle') }}" class="btn btn-success pull-right">
                    <i class="fa fa-plus"></i> New Jobcard
                </a>
            </div>
        </div>
        <div class="clearfix"></div>

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <div class="row">
            <div class="col-md-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Unclosed Job Cards <small>status: Open / In Workshop</small></h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <table class="table table-striped table-bordered" id="jobcardTable">
                            <thead>
                                <tr>
                                    <th>RO No</th>
                                    <th>Registration</th>
                                    <th>Variant</th>
                                    <th>Customer</th>
                                    <th>Mobile</th>
                                    <th>SA</th>
                                    <th>RO Type</th>
                                    <th>Open Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($unclosedJobs as $job)
                                <tr>
                                    <td><strong>{{ $job->Jobc_id }}</strong></td>
                                    <td>{{ $job->Registration }}</td>
                                    <td>{{ $job->Variant }}</td>
                                    <td>{{ $job->Customer_name }}</td>
                                    <td>{{ $job->mobile }}</td>
                                    <td>{{ $job->SA }}</td>
                                    <td>{{ $job->RO_type }}</td>
                                    <td>{{ $job->Open_date_time }}</td>
                                    <td>
                                        @if($job->status == '0')
                                            <span class="label label-warning">Open</span>
                                        @elseif($job->status == '1')
                                            <span class="label label-info">In Workshop</span>
                                        @endif
                                    </td>
                                    <td>
                                        <a href="{{ route('jobcard.additional', $job->Jobc_id) }}"
                                           class="btn btn-xs btn-primary">
                                            <i class="fa fa-edit"></i> Manage
                                        </a>
                                    </td>
                                </tr>
                                @empty
                                <tr><td colspan="10" class="text-center">No unclosed jobcards found.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
$(document).ready(function() {
    $('#jobcardTable').DataTable({ "order": [[7, "desc"]] });
});
</script>
@endpush
@endsection
